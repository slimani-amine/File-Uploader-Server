# SoftyShop

Welcome to SoftyShop, your one-stop solution for all things soft and shopping!

## Getting Started

To get started with SoftyShop, follow these simple steps:

1. Run `npm i` to install dependencies.

2. Start the server using Docker:
   - `npm run docker-dev-start -- -b`.

3. Once the server is up and running, use `npm run dev` to run the project.

## Database Setup

To populate your database with an initial user, you can use the following SQL query:

```sql
INSERT INTO users (id, email, firstName, lastName, password, role, phoneNumber, picture, confirmed_email, isVerified, createdAt, updatedAt)
VALUES
('a80816d3-2ac9-4bdf-a737-5209ac6752c4', 'admin@admin.com', 'admin', 'admin', '$2a$10$WLAr.87UraOheDchm5xa3.CwZbyNFk1AKiwlrFkyH5E1ik4NPjQlS', 'admin', '56251081', 'https://softyshopapi.lissene.dev/images/default.png', 1, 1, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());


Admin Credentials
Email: admin@admin.com
Password: bookstoresAdmin

Happy shopping with SoftyShop! 🛍️🌟