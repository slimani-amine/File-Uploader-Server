import * as express from "express";
import * as cookieParser from "cookie-parser";
import v1ApiRouter from "./v1/presenters/routes/api";
import getV1AuthRouter from "./v1/presenters/routes/auth";
import { handleErrorMiddleware } from "./v1/presenters/middlewares/errors/handleError.middleware";
import { requestInterceptor } from "./v1/presenters/middlewares/interceptors/request.interceptor";
import { responseInterceptor } from "./v1/presenters/middlewares/interceptors/response.interceptor";
import * as swaggerUi from "swagger-ui-express";
import * as swaggerJsDoc from "swagger-jsdoc";
import * as path from "path";
import { DOCS_API_BASE_URL, PORT, STATIC_FILES_PATH } from "./config";
import { logger } from "./v1/core/logger/logger";
import * as http from "http";
import { Server } from "socket.io";

const app = express();
const server = http.createServer(app);
export const io = new Server(server);

io.on("connection", (socket) => {
  console.log("A user connected");
  const emitNotification = (event, message) => {
    io.emit("notifications", `${event}: ${message}`);
  };
  const events = [
    { name: "newOrder", message: "New order placed" },
    { name: "OrderPayed", message: "Order Payed" },
    { name: "on_delivery", message: "Your Order now is on Delivery" },
    { name: "delivered", message: "Your Order now is on delivered" },
    { name: "cancelled", message: "Oops your order cancelled" },
  ];
  events.forEach(({ name, message }) => {
    socket.on(name, (orderDetails) => {
      emitNotification(message, orderDetails);
    });
  });
});

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Content-Type, Authorization, x-refresh"
  );

  if (req.method === "OPTIONS") {
    res.sendStatus(200);
  } else {
    next();
  }
});

app.use(express.json());
app.use(cookieParser());
app.use(requestInterceptor);
app.use(responseInterceptor);
app.use("/static", express.static(STATIC_FILES_PATH));

app.use("/v1/api", v1ApiRouter);
app.use("/v1/auth", getV1AuthRouter());

const swaggerDefinition = {
  openapi: "3.0.3",
  info: {
    title: "SoftyShop Api",
    description: "SoftyShop Api Docs",
    version: "1.0.0",
  },
  servers: [
    {
      url: DOCS_API_BASE_URL,
      description: "Local server",
    },
  ],
};

const options = {
  swaggerDefinition,
  apis: [path.resolve(__dirname, "../docs/**/*.yaml")],
};
app.use(handleErrorMiddleware);

const swaggerDoc = swaggerJsDoc(options);

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDoc));

server.on("close", () => {
  logger.log("APP", `SERVER CLOSED`);
});

server.on("error", (error) => {
  console.error("Express App Error:", error);
});

export default app;
