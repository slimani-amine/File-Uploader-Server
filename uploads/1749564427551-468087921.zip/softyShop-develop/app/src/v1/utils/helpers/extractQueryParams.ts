export const extractQueryParams = (url: string) => {
  const queryString = url.split("?")[1]; // Extract query string part of the URL
  const queryParams: { [key: string]: any } = {};
  if (queryString) {
    const pairs = queryString.split("&"); // Split query string into key-value pairs
    pairs.forEach((pair) => {
      const [key, value] = pair.split("="); // Split key-value pair by "="
      if (key === "brand_ids" && value.includes("-")) {
        // If value contains hyphens, split it into an array
        queryParams[key] = value.split("-");
      } else {
        queryParams[key] = value; // Otherwise, assign the value directly
      }
    });
  }
  return queryParams;
};
