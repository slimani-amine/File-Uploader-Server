import { getVendorStoresUseCase } from "../../../usecases/api/stores/getVendorStores.usecase";
import { Request, Response, NextFunction } from "express";

export const myStoreMiddleware = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const storeId = req.params.id;
    const userId = req.user.id;
    const role = req.user?.role;

    if (role !== "vendor") {
      return next(); 
    }

    const myStores = await getVendorStoresUseCase({ userId });

    const isStoreInMyStores = myStores.storesFound.some((store) => {
      return store.id == storeId;
    });

    if (!isStoreInMyStores) {
      return res.status(403).json({
        message: "You do not have access to this store.",
      }); 
    }

    next(); 
  } catch (error) {
    next(error); 
  }
};
