import {
  DeleteManyProductCreatorsUseCaseType,
  deleteManyProductCreatorsUseCase,
} from "../../../../usecases/api/productCreator/deleteManyProductCreators.usecase";
import { NextFunction, Request, Response } from "express";

export const deleteManyProductCreatorsControllerBase =
  (deleteManyProductCreatorsUseCase: DeleteManyProductCreatorsUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const queryParams = req.body.ids;
      const result = await deleteManyProductCreatorsUseCase(queryParams);
      res.status(200).send({
        message: "ProductCreators deleted successfully",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const deleteManyProductCreatorsController = deleteManyProductCreatorsControllerBase(
  deleteManyProductCreatorsUseCase
);
