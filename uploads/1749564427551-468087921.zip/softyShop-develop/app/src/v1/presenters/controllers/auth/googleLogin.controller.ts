import {
  LoginWithGoogleUseCaseType,
  loginWithGoogleUseCase,
} from "../../../usecases/auth/loginWithGoogle.usecase";
import { Request, Response, NextFunction } from "express";
import { TOKENS_INFO } from "../../../../config";
import { exceptionService } from "../../../core/errors/exceptions";

export const loginWithGoogleControllerBase =
  (loginWithGoogleUseCase: LoginWithGoogleUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const googleToken = req?.body?.idToken;
      if (!googleToken) {
        exceptionService.notFoundException({
          message: "Google token is missing",
        });
      }

      const result = await loginWithGoogleUseCase(googleToken);
      res.cookie(TOKENS_INFO.REFRESH_TOKEN_COOKIE_NAME, result.refreshToken, {
        sameSite: "none",
        httpOnly: true,
        secure: true,
        maxAge: TOKENS_INFO.REFRESH_TOKEN_EXPIRATION_IN_MILLISECONDS,
      });
      res.cookie(TOKENS_INFO.ACCESS_TOKEN_COOKIE_NAME, result.accessToken, {
        sameSite: "none",
        httpOnly: true,
        secure: true,
        maxAge: TOKENS_INFO.ACCESS_TOKEN_EXPIRATION_IN_MILLISECONDS,
      });

      res.status(200).send({
        message: "successfully connected",
        data: {
          user: result.user,
          accessToken: result.accessToken,
          refreshToken: result.refreshToken,
        },
      });
    } catch (err) {
      next(err);
    }
  };

export const loginWithGoogleController = loginWithGoogleControllerBase(
  loginWithGoogleUseCase
);
