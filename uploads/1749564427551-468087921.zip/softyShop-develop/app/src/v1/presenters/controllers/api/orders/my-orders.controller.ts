import { Request, Response, NextFunction } from "express";
import {
  myOrdersUseCaseType,
  myOrdersUseCase,
} from "../../../../usecases/api/orders/my-orders.usecase";
import { exceptionService } from "../../../../core/errors/exceptions";
import { extractQueryParams } from "../../../../utils/helpers/extractQueryParams";

export const myOrdersControllerBase =
  (myOrdersUseCase: myOrdersUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userId = req?.user?.id;
      const { page, perPage } = extractQueryParams(req.originalUrl);
      const pagination = {
        page: parseInt(page as string) || 1,
        perPage: parseInt(perPage as string) || 10,
      };
      const order = await myOrdersUseCase(userId, pagination);
      if (!order) {
        exceptionService.notFoundException({
          message: "Order not found",
        });
      }

      res.status(200).send({
        message: "Order retrieved successfully",
        data: {
          docs: order.orders,
          meta: { totalRecords: order.totalRecords },
        },
      });
    } catch (err) {
      next(err);
    }
  };

export const myOrdersController = myOrdersControllerBase(myOrdersUseCase);
