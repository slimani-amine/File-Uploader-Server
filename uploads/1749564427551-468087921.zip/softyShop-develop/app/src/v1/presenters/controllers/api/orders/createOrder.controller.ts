import { cartRepo } from "../../../../data/repositories/cart.repsitory";
import {
  createOrderUseCase,
  createOrderUseCaseType,
} from "../../../../usecases/api/orders/createOrder.usecase";
import { NextFunction, Request, Response } from "express";
import { exceptionService } from "../../../../core/errors/exceptions";
import { orderRepo } from "../../../../data/repositories/orders.repository";
import { addressRepo } from "../../../../data/repositories/addresses.repository";
import { paymentMethodRepo } from "../../../../data/repositories/paymentMethod.repository";
import { trimAndValidateSchemaPayload } from "../../../../utils/validation/validate.schema";
import createOrderSchema from "../../../schemas/orders/createOrder.schema";
import { usersRepo } from "../../../../data/repositories/users.repository";

const createOrderControllerBase =
  (createOrderUseCase: createOrderUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    req.body.cartId = req.user.cartId;
    req.body.userId = req.user.id;
    try {
      const cart = await cartRepo.findAll({
        relations: { cartProducts: true },
        where: { id: req.body.cartId },
        select: {
          cartProducts: true,
        },
      });

      if (cart[0].totalQuantity === 0) {
        exceptionService.notFoundException({
          message: "Empty Cart",
        });
      }
      const address = await addressRepo.findOne({
        where: { id: req.body.address_id },
      });

      if (!address) {
        exceptionService.badRequestException({
          message: "address not found",
        });
      }

      const paymentMethod = await paymentMethodRepo.findOne({
        where: { id: req.body.paymentMethod_id },
      });

      if (!paymentMethod) {
        exceptionService.badRequestException({
          message: "payment Method not found",
        });
      }
      const order = await orderRepo.findOne({
        relations: { cart: true },
        where: { cart: { id: req.body.cartId } },
      });

      // if (order) {
      //   exceptionService.notFoundException({
      //     message: "Already have order Pay it first",
      //   });
      //   return order;
      // }
      const result = await createOrderUseCase(req?.body);
      const newCart = await cartRepo.createCart();
      const user = await usersRepo.findOne({ where: { id: req.user.id } });
      const updateUser = await usersRepo.updateOne(user, { cart:newCart });

      // const notif = await createNewNotifUseCase({
      //   message: "order created successfully",
      //   user_id: req.body.userId,
      //   order_id: result.orders.id,
      // });

      // io.emit("newOrder", notif);

      return res.status(201).json({
        message: "Order added successfully",
        data: {
          order: result.orders,
        },
      });
    } catch (error) {
      next(error);
    }
  };

export function validateCreateOrderPayload(
  payload: Partial<any>
): Partial<any> {
  trimAndValidateSchemaPayload<Partial<any>>(createOrderSchema, payload);
  return payload;
}

const createOrderController = createOrderControllerBase(createOrderUseCase);
export { createOrderControllerBase, createOrderController };
