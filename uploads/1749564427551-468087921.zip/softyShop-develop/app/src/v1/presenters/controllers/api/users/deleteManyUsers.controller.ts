import {
  DeleteManyUsersUseCaseType,
  deleteManyUsersUseCase,
} from "../../../../usecases/api/users/deleteManyUsers.usecase";
import { NextFunction, Request, Response } from "express";

export const deleteManyUsersControllerBase =
  (deleteManyUsersUseCase: DeleteManyUsersUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const queryParams = req.body.ids;
      const result = await deleteManyUsersUseCase(queryParams);
      res.status(200).send({
        message: "Users deleted successfully",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const deleteManyUsersController = deleteManyUsersControllerBase(
  deleteManyUsersUseCase
);
