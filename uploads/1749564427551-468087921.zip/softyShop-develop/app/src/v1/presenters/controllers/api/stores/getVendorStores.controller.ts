import { extractQueryParams } from "../../../../utils/helpers/extractQueryParams";
import {
  getVendorStoresUseCase,
  GetVendorStoresUseCaseType,
} from "../../../../usecases/api/stores/getVendorStores.usecase";
import { NextFunction, Request, Response } from "express";

export const getVendorStoresControllerBase =
  (getVendorStoresUseCase: GetVendorStoresUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    const userId = req.user.id;
    try {
      const { page, perPage, ...queryParams } = extractQueryParams(
        req.originalUrl
      );
      queryParams.userId = userId;
      let pagination = null;
      if (page && perPage) {
        pagination = {
          page: parseInt(page as string) || 1,
          perPage: parseInt(perPage as string) || 10,
        };
      }

      const result = await getVendorStoresUseCase(queryParams, pagination);
      res.status(200).send({
        message: "Success",
        data: {
          docs: result.storesFound,
          meta: { totalRecords: result.totalRecords },
        },
      });
    } catch (err) {
      next(err);
    }

  };

export const getVendorStoresController = getVendorStoresControllerBase(
  getVendorStoresUseCase
);
