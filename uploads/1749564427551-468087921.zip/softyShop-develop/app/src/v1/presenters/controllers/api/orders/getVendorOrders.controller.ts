import { Request, Response, NextFunction } from "express";
import { exceptionService } from "../../../../core/errors/exceptions";
import {
  getVendorOrdersUseCase,
  getVendorOrdersUseCaseType,
} from "../../../../usecases/api/orders/getVendorOrders.usecase";
import { extractQueryParams } from "../../../../utils/helpers/extractQueryParams";

export const getVendorOrdersControllerBase =
  (getVendorOrdersUseCase: getVendorOrdersUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    const userId = req.user.id;
    const { page, perPage, ...queryParams } = extractQueryParams(
      req.originalUrl
    );
    const pagination = {
      page: parseInt(page as string) || 1,
      perPage: parseInt(perPage as string) || 10,
    };
    try {
      const result = await getVendorOrdersUseCase(
        userId,
        queryParams,
        pagination
      );

      if (!result) {
        exceptionService.notFoundException({
          message: "Order not found",
        });
      }

      res.status(200).send({
        message: "Order retrieved successfully",
        data: {
          docs: result.orders,
          meta: { totalRecords: result.totalRecords },
        },
      });
    } catch (err) {
      next(err);
    }
  };

export const getVendorOrdersController = getVendorOrdersControllerBase(
  getVendorOrdersUseCase
);
