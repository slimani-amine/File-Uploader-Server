import {
  DeleteManyMethodsUseCaseType,
  deleteManyMethodsUseCase,
} from "../../../../usecases/api/paymentMethod/deleteManyMethods.usecase"
import { NextFunction, Request, Response } from "express";

export const deleteManyMethodsControllerBase =
  (deleteManyMethodsUseCase: DeleteManyMethodsUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const queryParams = req.body.ids;
      const result = await deleteManyMethodsUseCase(queryParams);
      res.status(200).send({
        message: "Methods deleted successfully",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const deleteManyMethodsController = deleteManyMethodsControllerBase(
  deleteManyMethodsUseCase
);
