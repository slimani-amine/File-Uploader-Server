import { Request, Response, NextFunction } from "express";
import { productRepo } from "../../../../data/repositories/product.repository";
import {
  PublishProductUseCaseType,
  publishProductUseCase,
} from "../../../../usecases/api/products/publishProduct.usecase";
import { exceptionService } from "../../../../core/errors/exceptions";

export const publishProductControllerBase =
  (publishProductUseCase: PublishProductUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const productId = req.params.productId;
      const product = await productRepo.findOne({ where: { id: productId } });

      if (!product) {
        exceptionService.badRequestException({
          message: "Product not found",
        });
      }
      const updatePayload = { isPublished: !product.isPublished };
      const result = await publishProductUseCase(product, updatePayload);

      res.status(201).send({
        message: "Product published successfully",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const publishProductController = publishProductControllerBase(
  publishProductUseCase
);
