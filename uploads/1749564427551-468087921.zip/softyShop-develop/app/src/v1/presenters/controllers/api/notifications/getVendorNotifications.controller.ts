import {
  getVendorNotificationsUseCase,
  getVendorNotificationsUseCaseType,
} from "../../../../usecases/api/notifications/getVendorNotifications.usecase";
import { NextFunction, Request, Response } from "express";

export const getVendorNotificationsControllerBase =
  (getVendorNotificationsUseCase: getVendorNotificationsUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getVendorNotificationsUseCase( req.user.id);
      res.status(200).send({
        message: "success",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const getVendorNotificationsController =
  getVendorNotificationsControllerBase(getVendorNotificationsUseCase);
