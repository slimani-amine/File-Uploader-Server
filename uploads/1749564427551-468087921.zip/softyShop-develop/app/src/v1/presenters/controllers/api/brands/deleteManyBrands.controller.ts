import {
  DeleteManyBrandsUseCaseType,
  deleteManyBrandsUseCase,
} from "../../../../usecases/api/brands/deleteManyBrands.usecase";
import { NextFunction, Request, Response } from "express";

export const deleteManyBrandsControllerBase =
  (deleteManyBrandsUseCase: DeleteManyBrandsUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const queryParams = req.body.ids;
      const result = await deleteManyBrandsUseCase(queryParams);
      res.status(200).send({
        message: "Brands deleted successfully",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const deleteManyBrandsController = deleteManyBrandsControllerBase(
  deleteManyBrandsUseCase
);
