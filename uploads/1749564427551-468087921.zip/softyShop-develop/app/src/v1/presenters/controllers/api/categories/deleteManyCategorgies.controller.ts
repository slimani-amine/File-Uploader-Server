import {
  DeleteManyCategoriesUseCaseType,
  deleteManyCategoriesUseCase,
} from "../../../../usecases/api/categories/deleteManyCategories.usecase";
import { NextFunction, Request, Response } from "express";

export const deleteManyCategoriesControllerBase =
  (deleteManyCategoriesUseCase: DeleteManyCategoriesUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const queryParams = req.body.ids;
      const result = await deleteManyCategoriesUseCase(queryParams);
      res.status(200).send({
        message: "Categories deleted successfully",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const deleteManyCategoriesController = deleteManyCategoriesControllerBase(
  deleteManyCategoriesUseCase
);
