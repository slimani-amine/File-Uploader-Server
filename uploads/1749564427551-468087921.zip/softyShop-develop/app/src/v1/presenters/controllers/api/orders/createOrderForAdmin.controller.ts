import { cartRepo } from "../../../../data/repositories/cart.repsitory";
import {
  createOrderUseCase,
  createOrderUseCaseType,
} from "../../../../usecases/api/orders/createOrder.usecase";
import { NextFunction, Request, Response } from "express";
import { exceptionService } from "../../../../core/errors/exceptions";

import { addManyProductsToCartUseCase } from "../../../../usecases/api/cartProduct/addManyProductsToCart.usecase";
import { usersRepo } from "../../../../data/repositories/users.repository";
import { addressRepo } from "../../../../data/repositories/addresses.repository";
import { paymentMethodRepo } from "../../../../data/repositories/paymentMethod.repository";
import { trimAndValidateSchemaPayload } from "../../../../utils/validation/validate.schema";
import createOrderSchema from "../../../schemas/orders/createOrderForAdmin.schema";

const createOrderForAdminControllerBase =
  (createOrderUseCase: createOrderUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    const userId = req.body.userId;

    const cart = await cartRepo.createCart();
    const user = await usersRepo.findOne({
      where: {
        id: userId,
      },
    });
    req.body.cartId = cart.id;
    const addProductPayload = {
      cart: req.body.products,
      userId,
      cartId: cart.id,
    };
    const result = await addManyProductsToCartUseCase(addProductPayload);
    const updateUser = await usersRepo.updateOne(user, { cart });

    if (result) {
      try {

        const address = await addressRepo.findOne({
          where: { id: req.body.addressId },
        });

        if (!address) {
          exceptionService.badRequestException({
            message: "address not found",
          });
        }

        const paymentMethod = await paymentMethodRepo.findOne({
          where: { id: req.body.paymentMethodId },
        });

        if (!paymentMethod) {
          exceptionService.badRequestException({
            message: "payment Method not found",
          });
        }
        const result = await createOrderUseCase(req?.body);

        return res.status(201).json({
          message: "Order added successfully",
          data: {
            order: result.orders,
          },
        });
      } catch (error) {
        next(error);
      }
    }
  };

export function validateCreateOrderPayload(
  payload: Partial<any>
): Partial<any> {
  trimAndValidateSchemaPayload<Partial<any>>(createOrderSchema, payload);
  return payload;
}

const createOrderForAdminController =
  createOrderForAdminControllerBase(createOrderUseCase);
export { createOrderForAdminControllerBase, createOrderForAdminController };
