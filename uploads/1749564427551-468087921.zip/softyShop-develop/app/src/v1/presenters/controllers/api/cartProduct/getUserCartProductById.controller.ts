import {
  getUserCartProductsByIdUseCase,
  getUserCartProductsByIdUseCaseType,
} from "../../../../usecases/api/cartProduct/getUserCartProductsById.usecase";
import { NextFunction, Request, Response } from "express";

export const getUserCartProductsByIdControllerBase =
  (getUserCartProductsByIdUseCase: getUserCartProductsByIdUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    const cartId = req?.params?.cartId;

    try {
      const result = await getUserCartProductsByIdUseCase({ cartId });
      res.status(200).send({
        message: "success",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const getUserCartProductsByIdController = getUserCartProductsByIdControllerBase(
  getUserCartProductsByIdUseCase
);
