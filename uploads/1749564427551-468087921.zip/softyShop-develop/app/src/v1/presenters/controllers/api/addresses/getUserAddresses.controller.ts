import { extractQueryParams } from "../../../../utils/helpers/extractQueryParams";
import {
  GetUserAddressesUseCaseType,
  getUserAddressesUseCase,
} from "../../../../usecases/api/addresses/getUserAddresses.usecase";
import { NextFunction, Request, Response } from "express";

export const getUserAddressesControllerBase =
  (getUserAddressesUseCase: GetUserAddressesUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    const userId = req.params.userId;
    const { page, perPage } = extractQueryParams(req.originalUrl);
    const pagination = {
      page: parseInt(page as string) || 1,
      perPage: parseInt(perPage as string) || 10,
    };
    try {
      const result = await getUserAddressesUseCase(userId,pagination );
      res.status(200).send({
        message: "Success",
        data: {
          docs: result.addresses,
          meta: { totalRecords: result.totalRecords },
        },
      });
    } catch (err) {
      next(err);
    }
  };

export const getUserAddressesController = getUserAddressesControllerBase(
  getUserAddressesUseCase
);
