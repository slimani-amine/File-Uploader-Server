import { Request, Response, NextFunction } from "express";
import {
  UpdateUserProfileUseCaseType,
  updateUserProfileUseCase,
} from "../../../../usecases/api/users/updateUserProfile.usecase";

export const updateUserProfileControllerBase =
  (updateUserProfileUseCase: UpdateUserProfileUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await updateUserProfileUseCase(
        req?.params.userId,
        req?.body
      );

      res.status(201).send({
        message: "Your profile has been successfully updated",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const updateUserProfileController = updateUserProfileControllerBase(
  updateUserProfileUseCase
);
