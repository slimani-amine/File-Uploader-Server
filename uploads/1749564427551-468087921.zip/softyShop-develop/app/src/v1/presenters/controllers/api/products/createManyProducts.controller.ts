import { storeRepo } from "../../../../data/repositories/store.repository";
import {
  createProductUseCase,
  createProductUseCaseType,
} from "../../../../usecases/api/products/createProduct.usecase";
import { NextFunction, Request, Response } from "express";
import { exceptionService } from "../../../../core/errors/exceptions";
import { brandRepo } from "../../../../data/repositories/brand.repository";
import { productCreatorRepo } from "../../../../data/repositories/productCreator.repository";
import { categoryRepo } from "../../../../data/repositories/category.repository";

const createManyProductsControllerBase =
  (createManyProductsUseCase: createProductUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      let result = [];
      const store = await storeRepo.findOne({ where: { id: req.params.id } });
      if (!store) {
        throw new Error("Store not found");
      }

      req.body =
        req.body &&
        req.body.length > 0 &&
        req?.body?.map((item: any) => ({
          brand_id: item.brand_id,
          category_id: item.category_id,
          creator_id: item.creator_id,
          description: item.description,
          discount: item.discount,
          images: item.images,
          initialPrice: item.initialPrice,
          name: item.name,
          stockNumber: item.stockNumber,
        }));

      for (const item of req.body) {
        try {
          item.store_id = req.params.id;
          const brand = await brandRepo.findOne({
            where: { id: item?.brand_id },
          });
          if (!brand) {
            throw new Error("Brand not found");
          }

          const productCreator = await productCreatorRepo.findOne({
            where: { id: item?.creator_id },
          });

          if (!productCreator) {
            throw new Error("Product Creator not found");
          }
          const category = await categoryRepo.findOne({
            where: { id: item.categoryId },
          });
          if (!category) {
            throw new Error("Category Creator not found");
          }

          const res = await createManyProductsUseCase(item);
          if (res) {
            result.push(res);
          }
        } catch (error: any) {
          throw new Error(error);
        }
      }

      return res.status(201).json({
        message: "Product added successfully",
        data: {
          product: result,
        },
      });
    } catch (error) {
      next(error);
    }
  };

const createManyProductsController =
  createManyProductsControllerBase(createProductUseCase);
export { createManyProductsControllerBase, createManyProductsController };
