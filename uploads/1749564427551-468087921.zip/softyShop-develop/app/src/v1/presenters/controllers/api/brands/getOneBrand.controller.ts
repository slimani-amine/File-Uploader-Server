import {
  getOneBrandUseCase,
  getOneBrandUseCaseType,
} from "../../../../usecases/api/brands/getOneBrand.usecase";
import { NextFunction, Request, Response } from "express";

export const getOneBrandControllerBase =
  (getOneBrandUseCase: getOneBrandUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getOneBrandUseCase(req?.params.brandId);
      res.status(200).send({
        message: "success",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const getOneBrandController = getOneBrandControllerBase(
  getOneBrandUseCase
);
