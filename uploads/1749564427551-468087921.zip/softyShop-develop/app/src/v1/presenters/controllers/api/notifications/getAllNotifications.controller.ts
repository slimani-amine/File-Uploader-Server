import {
  getAllNotificationsUseCase,
  getAllNotificationsUseCaseType,
} from "../../../../usecases/api/notifications/getAllNotifications.usecase";
import { NextFunction, Request, Response } from "express";

export const getAllNotificationsControllerBase =
  (getAllNotificationsUseCase: getAllNotificationsUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getAllNotificationsUseCase();
      res.status(200).send({
        message: "success",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const getAllNotificationsController = getAllNotificationsControllerBase(
  getAllNotificationsUseCase
);
