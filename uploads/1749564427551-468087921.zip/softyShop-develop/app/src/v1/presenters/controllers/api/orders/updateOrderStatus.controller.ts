import { Request, Response, NextFunction } from "express";
import {
  updateOrderStatusUseCaseType,
  updateOrderStatusUseCase,
} from "../../../../usecases/api/orders/updateOrderStatus.usecase";
import { exceptionService } from "../../../../core/errors/exceptions";
import { orderRepo } from "../../../../data/repositories/orders.repository";
import { IOrder } from "../../../../domain/order/order";
import { trimAndValidateSchemaPayload } from "../../../../utils/validation/validate.schema";
import updateOrderStatusSchema from "../../../schemas/orders/updateOrderStatus.schema";
import { io } from "../../../../../server";
import { createNewNotifUseCase } from "../../../../usecases/api/notifications/createNewNotif.usecase";

export const updateOrderStatusControllerBase =
  (updateOrderStatusUseCase: updateOrderStatusUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      validateUpdateOrderPayload(req.body);
      const orderId = req.params.id;
      const order = await orderRepo.findOne({
        relations: { user: true },
        where: { id: orderId },
        select: {
          user: { id: true },
        },
      });

      if (!order) {
        exceptionService.badRequestException({
          message: "Order not found",
        });
      }

      const updatePayload = {
        status: req.body.status,
      };
      const result = await updateOrderStatusUseCase(order, updatePayload);
      const notif = await createNewNotifUseCase({
        message: `Order ${req.body.status}`,
        user_id: order.user.id,
        order_id: order.id,
      });
      io.emit(`${req.body.status}`, result);
      res.status(200).send({
        message: "Order updated successfully",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };
export function validateUpdateOrderPayload(
  payload: Partial<IOrder>
): Partial<IOrder> {
  trimAndValidateSchemaPayload<Partial<IOrder>>(
    updateOrderStatusSchema,
    payload
  );
  return payload;
}

export const updateOrderStatusController = updateOrderStatusControllerBase(
  updateOrderStatusUseCase
);
