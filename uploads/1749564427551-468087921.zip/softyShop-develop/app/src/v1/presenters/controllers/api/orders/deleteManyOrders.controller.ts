import {
  DeleteManyOrdersUseCaseType,
  deleteManyOrdersUseCase,
} from "../../../../usecases/api/orders/deleteManyOrders.usecase";
import { NextFunction, Request, Response } from "express";

export const deleteManyOrdersControllerBase =
  (deleteManyOrdersUseCase: DeleteManyOrdersUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const queryParams = req.body.ids;
      const result = await deleteManyOrdersUseCase(queryParams);
      res.status(200).send({
        message: "Orders deleted successfully",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const deleteManyOrdersController = deleteManyOrdersControllerBase(
  deleteManyOrdersUseCase
);
