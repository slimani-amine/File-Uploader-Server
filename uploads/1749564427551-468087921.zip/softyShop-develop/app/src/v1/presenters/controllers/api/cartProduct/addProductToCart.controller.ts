import { cartRepo } from "../../../../data/repositories/cart.repsitory";
import {
  AddProductToCartUseCaseType,
  addProductToCartUseCase,
} from "../../../../usecases/api/cartProduct/addProductToCart.usecase";
import { Request, Response, NextFunction } from "express";
import { usersRepo } from "../../../../data/repositories/users.repository";

export const addProductToCartControllerBase =
  (addProductToCartUseCase: AddProductToCartUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    let cartId = req?.user?.cartId;
    const userId = req.user.id;

    try {
      if (!cartId) {
        const cart = await cartRepo.createCart();
        const user = await usersRepo.findOne({
          where: {
            id: userId,
          },
        });
        const updateUser = await usersRepo.updateOne(user, { cart });
        cartId = cart.id;
      }

      req.body.cartId = cartId;

      const result = await addProductToCartUseCase(req.body);

      res.status(201).send({
        message: "Product added to cart successfully",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const addProductToCartController = addProductToCartControllerBase(
  addProductToCartUseCase
);
