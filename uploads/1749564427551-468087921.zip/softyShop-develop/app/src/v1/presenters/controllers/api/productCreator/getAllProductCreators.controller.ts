import {
  getAllProductCreatorsUseCase,
  getAllProductCreatorsUseCaseType,
} from "../../../../usecases/api/productCreator/getAllProductCreators.usecase";
import { NextFunction, Request, Response } from "express";

export const getAllProductCreatorsControllerBase =
  (getAllProductCreatorsUseCase: getAllProductCreatorsUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getAllProductCreatorsUseCase(req?.query);
      res.status(200).send({
        message: "success",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const getAllProductCreatorsController = getAllProductCreatorsControllerBase(
  getAllProductCreatorsUseCase
);
