import { Request, Response, NextFunction } from "express";
import {
  payOrderUseCaseType,
  payOrderUseCase,
} from "../../../../usecases/api/orders/payOrder.usecase";
import { exceptionService } from "../../../../core/errors/exceptions";
import { orderRepo } from "../../../../data/repositories/orders.repository";
import { createNewNotifUseCase } from "../../../../usecases/api/notifications/createNewNotif.usecase";
import { io } from "../../../../../server";

export const payOrderControllerBase =
  (payOrderUseCase: payOrderUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const orderId = req.params.id;
      const userId = req.user.id;
      const order = await orderRepo.findOne({ where: { id: orderId } });

      if (!order) {
        exceptionService.badRequestException({
          message: "Order not found",
        });
      }

      const updatePayload = {
        isPaied: !order.isPaied,
      };

      const result = await payOrderUseCase(order, updatePayload, userId);

      const notif = await createNewNotifUseCase({
        message: "order Paied successfully",
        user_id: userId,
        order_id: order.id,
      });

      io.emit("OrderPayed", notif);

      res.status(200).send({
        message: "Order updated successfully",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const payOrderController = payOrderControllerBase(payOrderUseCase);
