import { Request, Response, NextFunction } from "express";
import {
  allOrdersUseCaseType,
  allOrdersUseCase,
} from "../../../../usecases/api/orders/allOrders.usecase";
import { exceptionService } from "../../../../core/errors/exceptions";
import { extractQueryParams } from "../../../../utils/helpers/extractQueryParams";

export const allOrdersControllerBase =
  (allOrdersUseCase: allOrdersUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    const { page, perPage, ...queryParams } = extractQueryParams(
      req.originalUrl
    );
    const pagination = {
      page: parseInt(page as string) || 1,
      perPage: parseInt(perPage as string) || 10,
    };
    try {
      const result = await allOrdersUseCase(queryParams, pagination);

      if (!result) {
        exceptionService.notFoundException({
          message: "Order not found",
        });
      }

      res.status(200).send({
        message: "Order retrieved successfully",
        data: {
          docs: result.orders,
          meta: { totalRecords: result.totalRecords },
        },
      });
    } catch (err) {
      next(err);
    }
  };

export const allOrdersController = allOrdersControllerBase(allOrdersUseCase);
