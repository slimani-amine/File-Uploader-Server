import {
  getUserNotificationsUseCase,
  getUserNotificationsUseCaseType,
} from "../../../../usecases/api/notifications/getUserNotifications.usecase";
import { NextFunction, Request, Response } from "express";

export const getUserNotificationsControllerBase =
  (getUserNotificationsUseCase: getUserNotificationsUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getUserNotificationsUseCase(req.user.id);
      res.status(200).send({
        message: "success",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const getUserNotificationsController =
  getUserNotificationsControllerBase(getUserNotificationsUseCase);
