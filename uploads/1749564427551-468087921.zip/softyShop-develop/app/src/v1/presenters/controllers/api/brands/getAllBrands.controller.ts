import {
  getAllBrandsUseCase,
  getAllBrandsUseCaseType,
} from "../../../../usecases/api/brands/getAllBrands.usecase";
import { NextFunction, Request, Response } from "express";

export const getAllBrandsControllerBase =
  (getAllBrandsUseCase: getAllBrandsUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getAllBrandsUseCase(req?.query);
      res.status(200).send({
        message: "success",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const getAllBrandsController =
  getAllBrandsControllerBase(getAllBrandsUseCase);
