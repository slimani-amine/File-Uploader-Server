import { extractQueryParams } from "../../../../utils/helpers/extractQueryParams";
import {
  GetAllProductUseCaseType,
  getAllProductsUseCase,
} from "../../../../usecases/api/products/getAllProductsN.usecase";

import { NextFunction, Request, Response } from "express";

export const getAllProductsControllerBase =
  (getAllProductsUseCase: GetAllProductUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { page, perPage, ...queryParams } = extractQueryParams(
        req.originalUrl
      );
      let pagination = null;
      if (page && perPage) {
        pagination = {
          page: parseInt(page as string) || 1,
          perPage: parseInt(perPage as string) || 10,
        };
      }

      const result = await getAllProductsUseCase(queryParams, pagination);
      res.status(200).send({
        message: "Success",
        data: {
          docs: result.productsFound,
          meta: { totalRecords: result.totalRecords },
        },
      });
    } catch (err) {
      next(err);
    }
  };

export const getAllProductsNController = getAllProductsControllerBase(
  getAllProductsUseCase
);
