import {
  GetStoreProductUseCaseType,
  getStoreProductUseCase,
} from "../../../../usecases/api/products/getStoreProducts.usecase";

import { NextFunction, Request, Response } from "express";
import { extractQueryParams } from "../../../../utils/helpers/extractQueryParams";
export const getStoreProductsControllerBase =
  (getStoreProductUseCase: GetStoreProductUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    const storeId = req.params?.id;
    try {
      const { page, perPage, ...queryParams } = extractQueryParams(
        req.originalUrl
      );
      const pagination = {
        page: parseInt(page as string) || 1,
        perPage: parseInt(perPage as string) || 10,
      };
      const result = await getStoreProductUseCase(
        storeId,
        queryParams,
        pagination
      );
      res.status(200).send({
        message: "success",
        data: {
          docs: result.productsFound,
          meta: { totalRecords: result.totalRecords },
        },
      });
    } catch (err) {
      next(err);
    }
  };

export const getStoreProductsController = getStoreProductsControllerBase(
  getStoreProductUseCase
);
