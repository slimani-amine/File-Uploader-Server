import {
  getOneProductCreatorUseCase,
  getOneProductCreatorUseCaseType,
} from "../../../../usecases/api/productCreator/getOneProductCreator.usecase";
import { NextFunction, Request, Response } from "express";

export const getOneProductCreatorControllerBase =
  (getOneProductCreatorUseCase: getOneProductCreatorUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getOneProductCreatorUseCase(req?.params.productCreatorId);
      res.status(200).send({
        message: "success",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const getOneProductCreatorController =
  getOneProductCreatorControllerBase(getOneProductCreatorUseCase);
