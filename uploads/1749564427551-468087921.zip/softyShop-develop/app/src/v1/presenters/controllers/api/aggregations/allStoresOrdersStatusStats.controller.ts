import { NextFunction, Request, Response } from "express";
import {
  allStoresStatsUseCase,
  allStoresStatsUseCaseType,
} from "../../../../usecases/api/aggregations/allStoresStats.usecase";

export const allStoresStatsControllerBase =
  (allStoresStatsUseCase: allStoresStatsUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    const userId = req.user.id;
    const { startDate, endDate } = req.query;

    try {
      const result = await allStoresStatsUseCase(
        userId,
        startDate as string,
        endDate as string
      );
      res.status(200).send({
        message: "Success",
        data: {
          result,
        },
      });
    } catch (err) {
      next(err);
    }
  };

export const allStoresStatsController = allStoresStatsControllerBase(
  allStoresStatsUseCase
);
