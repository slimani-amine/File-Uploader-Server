import { Request, Response, NextFunction } from "express";
import { productRepo } from "../../../../data/repositories/product.repository";
import {
  UpdateProductUseCaseType,
  updateProductUseCase,
} from "../../../../usecases/api/products/updateProduct.usecase";
import { categoryRepo } from "../../../../data/repositories/category.repository";
import { exceptionService } from "../../../../core/errors/exceptions";
import { productCreatorRepo } from "../../../../data/repositories/productCreator.repository";
import { brandRepo } from "../../../../data/repositories/brand.repository";

export const updateProductControllerBase =
  (updateProductUseCase: UpdateProductUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const productId = req.params.productId;
      const product = await productRepo.findOne({ where: { id: productId } });
      if (!product) {
        exceptionService.notFoundException({
          message: "Product not found",
        });
      }
      const category = await categoryRepo.findOne({
        where: { id: req.body?.category_id },
      });
      if (!category) {
        exceptionService.notFoundException({
          message: "Category not found",
        });
      }
      const productCreator = await productCreatorRepo.findOne({
        where: { id: req.body?.creator_id },
      });
      if (!productCreator) {
        exceptionService.notFoundException({
          message: "Creator not found",
        });
      }
      const brand = await brandRepo.findOne({
        where: { id: req.body?.brand_id },
      });
      if (!brand) {
        exceptionService.notFoundException({
          message: "Brand not found",
        });
      }
      const updatePayload = {
        name: req.body.name,
        description: req.body.description,
        initialPrice: req.body.initialPrice,
        price:
          req.body?.initialPrice -
          req.body?.initialPrice * (req.body?.discount / 100),

        images: JSON.stringify(req.body.images),
        discount: req.body.discount,
        stockNumber: req.body.stockNumber,
        quantity: req.body.quantity,
        category: { id: req.body.category_id },
        creator: { id: req.body.creator_id },
        brand: { id: req.body.brand_id },
      };

      const result = await updateProductUseCase(product, updatePayload);

      res.status(201).send({
        message: "Product updated successfully",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const updateProductController =
  updateProductControllerBase(updateProductUseCase);
