import {
  GetCartUseCaseType,
  getOneCartUseCase,
} from "../../../../usecases/api/cart/getOneCart.usecase";
import { NextFunction, Request, Response } from "express";

export const getOneCartControllerBase =
  (getOneCartUseCase: GetCartUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const cartId = req.params.cartId;
      const result = await getOneCartUseCase({ cartId });
      res.status(200).send({
        message: "success",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const getOneCartController = getOneCartControllerBase(getOneCartUseCase);
