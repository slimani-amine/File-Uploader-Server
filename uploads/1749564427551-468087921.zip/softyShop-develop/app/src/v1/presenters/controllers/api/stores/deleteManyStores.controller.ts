import {
  DeleteManyStoresUseCaseType,
  deleteManyStoresUseCase,
} from "../../../../usecases/api/stores/deleteManyStores.usecase";
import { NextFunction, Request, Response } from "express";

export const deleteManyStoresControllerBase =
  (deleteManyStoresUseCase: DeleteManyStoresUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const queryParams = req.body.ids;
      const result = await deleteManyStoresUseCase(queryParams);
      res.status(200).send({
        message: "Stores deleted successfully",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const deleteManyStoresController = deleteManyStoresControllerBase(
  deleteManyStoresUseCase
);
