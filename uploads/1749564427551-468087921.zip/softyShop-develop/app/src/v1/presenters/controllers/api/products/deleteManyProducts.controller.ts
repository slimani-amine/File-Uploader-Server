import {
  DeleteManyProductsUseCaseType,
  deleteManyProductsUseCase,
} from "../../../../usecases/api/products/deleteManyProducts.usecase";
import { NextFunction, Request, Response } from "express";

export const deleteManyProductsControllerBase =
  (deleteManyProductsUseCase: DeleteManyProductsUseCaseType) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const queryParams = req.body.ids;
      const result = await deleteManyProductsUseCase(queryParams);
      res.status(200).send({
        message: "Products deleted successfully",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  };

export const deleteManyProductsController = deleteManyProductsControllerBase(
  deleteManyProductsUseCase
);
