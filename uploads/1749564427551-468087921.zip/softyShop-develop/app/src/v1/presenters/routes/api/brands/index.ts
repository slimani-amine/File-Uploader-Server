import * as express from "express";
import { ControllerType } from "../../../../../types/controller";
import { isAuthentictedMiddleware } from "../../../middlewares/auth/isAuthenticated.middleware";
import { restrictToMiddleware } from "../../../middlewares/auth/restrictTo.middleware";
import { createBrandController } from "../../../controllers/api/brands/createBrand.controller";
import { deleteBrandController } from "../../../controllers/api/brands/deleteBrand.controller";
import { deleteManyBrandsController } from "../../../controllers/api/brands/deleteManyBrands.controller";
import { updateBrandController } from "../../../controllers/api/brands/updateBrand.controller";
import { getAllBrandsController } from "../../../controllers/api/brands/getAllBrands.controller";
import { getOneBrandController } from "../../../controllers/api/brands/getOneBrand.controller";

const router = express.Router();

const defaults = {
  createBrand: createBrandController,
  deleteBrand: deleteBrandController,
  deleteManyBrands: deleteManyBrandsController,
  updateBrand: updateBrandController,
  getAllBrands: getAllBrandsController,
  getOneBrand: getOneBrandController,
};

export function getBrandsApiRouter(
  controllers: {
    createBrand: ControllerType;
    deleteBrand: ControllerType;
    deleteManyBrands: ControllerType;
    updateBrand: ControllerType;
    getAllBrands: ControllerType;
    getOneBrand: ControllerType;
  } = defaults
) {
  router.use(isAuthentictedMiddleware);

  router
    .route("/")
    .get(controllers.getAllBrands) // get all brands
    .post(restrictToMiddleware("vendor", "admin"), controllers.createBrand) // post brand (only for vendor)
    .delete(restrictToMiddleware("vendor", "admin"),controllers.deleteManyBrands); // delete many brands

  router
    .route("/:brandId")
    .get(controllers.getOneBrand) // get one brand
    .delete(restrictToMiddleware("vendor", "admin"), controllers.deleteBrand) // delete a brand (only for vendor)
    .patch(restrictToMiddleware("vendor", "admin"), controllers.updateBrand); // update a brand (only for admin or vendor)

  return router;
}
