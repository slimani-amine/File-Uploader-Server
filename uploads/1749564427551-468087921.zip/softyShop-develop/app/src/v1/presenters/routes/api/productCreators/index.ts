import * as express from "express";
import { ControllerType } from "../../../../../types/controller";
import { restrictToMiddleware } from "../../../middlewares/auth/restrictTo.middleware";
import { createProductCreatorController } from "../../../controllers/api/productCreator/createProductCreator.controller";
import { deleteProductCreatorController } from "../../../controllers/api/productCreator/deleteProductCreator.controller";
import { updateProductCreatorController } from "../../../controllers/api/productCreator/updateProductCreator..controller";
import { getAllProductCreatorsController } from "../../../controllers/api/productCreator/getAllProductCreators.controller";
import { getOneProductCreatorController } from "../../../controllers/api/productCreator/getOneProductCreator.controller";
import { deleteManyProductCreatorsController } from "../../../controllers/api/productCreator/deleteManyProductCreators.controller";

const router = express.Router();

const defaults = {
  createProductCreator: createProductCreatorController,
  deleteProductCreator: deleteProductCreatorController,
  deleteManyProductCreators: deleteManyProductCreatorsController,
  updateProductCreator: updateProductCreatorController,
  getAllProductCreators: getAllProductCreatorsController,
  getOneProductCreator: getOneProductCreatorController,
};

export function getProductCreatorsApiRouter(
  controllers: {
    createProductCreator: ControllerType;
    deleteProductCreator: ControllerType;
    deleteManyProductCreators: ControllerType;
    updateProductCreator: ControllerType;
    getAllProductCreators: ControllerType;
    getOneProductCreator: ControllerType;
  } = defaults
) {

  router
    .route("/")
    .post(
      // restrictToMiddleware("vendor", "admin"),
      controllers.createProductCreator
    ) // post productCreator (only for vendor)
    .get(controllers.getAllProductCreators) // get all ProductCreators
    .delete(controllers.deleteManyProductCreators); // delete many ProductCreators

  router
    .route("/:productCreatorId")
    .get(controllers.getOneProductCreator) // get one ProductCreator
    .delete(restrictToMiddleware("vendor"), controllers.deleteProductCreator) // delete a productCreator (only for vendor)
    .patch(
      controllers.updateProductCreator
    ); //  update a productCreator (only for admin or vendor)



  return router;
}
