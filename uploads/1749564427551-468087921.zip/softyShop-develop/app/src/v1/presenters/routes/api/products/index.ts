import * as express from "express";
import { ControllerType } from "../../../../../types/controller";
import { isAuthentictedMiddleware } from "../../../middlewares/auth/isAuthenticated.middleware";
import { getAllProductsController } from "../../../controllers/api/products/getAllProducts.controller";
import { createReviewController } from "../../../controllers/api/reviews/createReview.controller";
import { deleteReviewController } from "../../../controllers/api/reviews/deleteReview.controller";
import { getAllProductReviewsController } from "../../../controllers/api/reviews/getAllProductReviews.controller";
import { restrictToMiddleware } from "../../../middlewares/auth/restrictTo.middleware";
import { updateReviewController } from "../../../controllers/api/reviews/updateReview.controller";
import { getOneProductController } from "../../../controllers/api/products/getOneProducts.controller";
import { getAllProductsNController } from "../../../controllers/api/products/getAllProductsN.controller";
import {
  VALIDATION_PATHS,
  validateSchemaMiddleware,
} from "../../../middlewares/schemas/validateSchema.middleware";
import { publishProductController } from "../../../controllers/api/products/publishProduct.controller";
import { updateProductController } from "../../../controllers/api/products/updateProduct.controller";
import { deleteProductController } from "../../../controllers/api/products/deleteProduct.controller";
import { deleteManyProductsController } from "../../../controllers/api/products/deleteManyProducts.controller";
import updateProductSchema from "../../../schemas/product/updateProduct.schema";
import { getVendorProductsController } from "../../../controllers/api/products/getVendorProducts.controller";

const router = express.Router();

const defaults = {
  getAllProducts: getAllProductsController,
  getAllProductsN: getAllProductsNController,
  addReview: createReviewController,
  productReviews: getAllProductReviewsController,
  deleteReview: deleteReviewController,
  updateReview: updateReviewController,
  getOneProduct: getOneProductController,
  getVendorProducts:getVendorProductsController,
  publishProduct: publishProductController,
  updateProduct: updateProductController,
  deleteProduct: deleteProductController,
  deleteManyProducts: deleteManyProductsController,
};

export function getProductsApiRouter(
  controllers: {
    getAllProducts: ControllerType;
    getAllProductsN: ControllerType;
    productReviews: ControllerType;
    addReview: ControllerType;
    deleteReview: ControllerType;
    updateReview: ControllerType;
    getOneProduct: ControllerType;
    getVendorProducts: ControllerType;
    publishProduct: ControllerType;
    updateProduct: ControllerType;
    deleteProduct: ControllerType;
    deleteManyProducts: ControllerType;
  } = defaults
) {
  router
    .route("/")
    .get(controllers.getAllProductsN) //get all products
    .delete(isAuthentictedMiddleware, controllers.deleteManyProducts); // delete many products

  router
    .route("/vendor")
    .get(isAuthentictedMiddleware,controllers.getVendorProducts) //get all vendor products

  router.route("/all").get(controllers.getAllProducts); //get all products

  router
    .route("/:productId")
    .get(controllers.getOneProduct)
    .delete(restrictToMiddleware("vendor"), controllers.deleteProduct) // delete a product (only for vendor)

    .patch(
      // restrictToMiddleware("admin", "vendor"),
      validateSchemaMiddleware(updateProductSchema, VALIDATION_PATHS.BODY),
      controllers.updateProduct
    ); // get one product / delete a product (only for vendor) / update a product (only for admin or vendor) // get one product
  router
    .route("/:productId/publish")
    .patch(
      isAuthentictedMiddleware,
      restrictToMiddleware("admin","vendor"),
      controllers.publishProduct
    ); // publish a product
  router.use(isAuthentictedMiddleware);

  router.route("/:id/reviews").get(controllers.productReviews); //get the product reviews

  router.route("/reviews").post(controllers.addReview); //create a new review

  router
    .route("/reviews/:id")
    .delete(controllers.deleteReview) //delete review
    .patch(controllers.updateReview); //update review

  return router;
}
