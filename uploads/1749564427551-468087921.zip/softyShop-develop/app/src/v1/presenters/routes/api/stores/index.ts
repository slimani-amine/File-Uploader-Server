import * as express from "express";
import { ControllerType } from "../../../../../types/controller";
import {
  VALIDATION_PATHS,
  validateSchemaMiddleware,
} from "../../../middlewares/schemas/validateSchema.middleware";
import { restrictToMiddleware } from "../../../middlewares/auth/restrictTo.middleware";
import { isAuthentictedMiddleware } from "../../../middlewares/auth/isAuthenticated.middleware";
import { createProductController } from "../../../controllers/api/products/createProduct.controller";
import { deleteProductController } from "../../../controllers/api/products/deleteProduct.controller";
import { getStoreProductsController } from "../../../controllers/api/products/getStoreProducts.controller";
import { getOneProductController } from "../../../controllers/api/products/getOneProducts.controller";
import { getAllProductsController } from "../../../controllers/api/products/getAllProducts.controller";
import { updateProductController } from "../../../controllers/api/products/updateProduct.controller";
import { getVendorNotificationsController } from "../../../controllers/api/notifications/getVendorNotifications.controller";
import { deleteManyProductsController } from "../../../controllers/api/products/deleteManyProducts.controller";
import { deleteManyStoresController } from "../../../controllers/api/stores/deleteManyStores.controller";
import { publishStoreController } from "../../../controllers/api/stores/publishStore.controller";
import { createStoreController } from "../../../controllers/api/stores/createStore.controller";
import { deleteStoresController } from "../../../controllers/api/stores/deleteStore.controller";
import { getOneStoreController } from "../../../controllers/api/stores/getOneStore.controller";
import { getVendorStoresController } from "../../../controllers/api/stores/getVendorStores.controller";
import { updateStoreController } from "../../../controllers/api/stores/updateStore.controller";
import createStoreSchema from "../../../schemas/store/createStore.schema";
import updateStoreSchema from "../../../schemas/store/updateStore.schema";
import publishStoreSchema from "../../../schemas/store/publish.schema";
import { publishProductController } from "../../../controllers/api/products/publishProduct.controller";
import { getAllStoresNController } from "../../../controllers/api/stores/getAllStoresN.controller";
import { createManyProductsController } from "../../../controllers/api/products/createManyProducts.controller";
import { allStoresStatsController } from "../../../controllers/api/aggregations/allStoresStats.controller";

const router = express.Router();

const defaults = {
  createStore: createStoreController,
  getStore: getAllStoresNController,
  deleteStore: deleteStoresController,
  deleteManyStores: deleteManyStoresController,
  getOneStore: getOneStoreController,
  getVendorStores: getVendorStoresController,
  updateStore: updateStoreController,
  publishStore: publishStoreController,
  createProduct: createProductController,
  createManyProducts: createManyProductsController,
  getAllProducts: getAllProductsController,
  getStoreProduct: getStoreProductsController,
  getOneProduct: getOneProductController,
  deleteProduct: deleteProductController,
  deleteManyProducts: deleteManyProductsController,
  updateProduct: updateProductController,
  publishProduct: publishProductController,
  getVendorNotifications: getVendorNotificationsController,
  allStoresStats: allStoresStatsController,
};

export function getStoresApiRouter(
  controllers: {
    createStore: ControllerType;
    getStore: ControllerType;
    deleteStore: ControllerType;
    deleteManyStores: ControllerType;
    getOneStore: ControllerType;
    getVendorStores: ControllerType;
    updateStore: ControllerType;
    publishStore: ControllerType;
    createProduct: ControllerType;
    createManyProducts: ControllerType;
    getAllProducts: ControllerType;
    getStoreProduct: ControllerType;
    deleteProduct: ControllerType;
    deleteManyProducts: ControllerType;
    updateProduct: ControllerType;
    publishProduct: ControllerType;
    getVendorNotifications: ControllerType;
    allStoresStats: ControllerType;
  } = defaults
) {
  router.route("/stats").get(
    isAuthentictedMiddleware,
    restrictToMiddleware("vendor", "admin"),
    controllers.allStoresStats
  );
  router
    .route("/")
    .get(controllers.getStore) // get all stores
    .post(
      isAuthentictedMiddleware,
      validateSchemaMiddleware(createStoreSchema, VALIDATION_PATHS.BODY),
      restrictToMiddleware("admin", "vendor"),
      // multerImageUpload.single("picture"),
      // transferFilePathToBodyMiddlewareBuilder("picture", FilePathTypes.IMAGES),
      controllers.createStore
    ) // create a new store (only for admin or vendors)
    .delete(
      isAuthentictedMiddleware,
      restrictToMiddleware("admin", "vendor"),
      controllers.deleteManyStores
    ); // delete many stores

  router
    .route("/:id/products")
    .post(
      isAuthentictedMiddleware,
      restrictToMiddleware("vendor", "admin"),
      // myStoreMiddleware,
      controllers.createProduct
    )
    .get(controllers.getStoreProduct); // get all product / post a product (only for vendor)

  router.route("/:id/products/many").post(
    isAuthentictedMiddleware,
    restrictToMiddleware("vendor", "admin"),
    // myStoreMiddleware,
    controllers.createManyProducts
  );

  router
    .route("/my-stores")
    .get(
      isAuthentictedMiddleware,
      // restrictToMiddleware("vendor", "admin"),
      controllers.getVendorStores
    ); // get vendor stores (only for admin or vendors)

  router
    .route("/:id")
    .delete(
      isAuthentictedMiddleware,
      restrictToMiddleware("admin", "vendor"),
      controllers.deleteStore
    ) // delete a store
    .get(controllers.getOneStore) // get one store
    .patch(
      isAuthentictedMiddleware,
      restrictToMiddleware("admin", "vendor"),
      validateSchemaMiddleware(updateStoreSchema, VALIDATION_PATHS.BODY),
      controllers.updateStore
    ); // update a store

  router
    .route("/:id/publish")
    .patch(
      isAuthentictedMiddleware,
      restrictToMiddleware("admin"),
      validateSchemaMiddleware(publishStoreSchema, VALIDATION_PATHS.BODY),
      controllers.publishStore
    ); // publish a store

  router
    .route("/my-stores/notifications")
    .get(
      restrictToMiddleware("admin", "vendor"),
      controllers.getVendorNotifications
    );

  return router;
}
