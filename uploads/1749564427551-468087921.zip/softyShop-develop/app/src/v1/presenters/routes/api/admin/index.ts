import * as express from "express";
import { ControllerType } from "../../../../../types/controller";
import { restrictToMiddleware } from "../../../middlewares/auth/restrictTo.middleware";
import { isAuthentictedMiddleware } from "../../../middlewares/auth/isAuthenticated.middleware";
import { createCategoryController } from "../../../controllers/api/categories/createCategory.controller";
import { deleteCategoryController } from "../../../controllers/api/categories/deleteCategory.controller";
import { getAllCategoryController } from "../../../controllers/api/categories/getAllCategories.controller";
import { updatecategoryController } from "../../../controllers/api/categories/updateCategory.controller";
import { createMethodController } from "../../../controllers/api/paymentMethod/createMethod.controller";
import { deletePayementMethodController } from "../../../controllers/api/paymentMethod/deleteMethod.controller";
import { getAllPayementMethodsController } from "../../../controllers/api/paymentMethod/getAllMethods.controller";
import { updatepaymentMethodController } from "../../../controllers/api/paymentMethod/updateMethod.controller";
import { getAllNotificationsController } from "../../../controllers/api/notifications/getAllNotifications.controller";
import { allOrdersController } from "../../../controllers/api/orders/allOrders.controller";
import { deleteManyCategoriesController } from "../../../controllers/api/categories/deleteManyCategorgies.controller";
import { deleteManyMethodsController } from "../../../controllers/api/paymentMethod/deleteManyMethods.controller";
import { deleteManyOrdersController } from "../../../controllers/api/orders/deleteManyOrders.controller";
import { getVendorOrdersController } from "../../../controllers/api/orders/getVendorOrders.controller";

const router = express.Router();

const defaults = {
  createCategory: createCategoryController,
  deleteCategory: deleteCategoryController,
  deleteManyCategories: deleteManyCategoriesController,
  getCategories: getAllCategoryController,
  updateCategory: updatecategoryController,
  createPaymentMethod: createMethodController,
  deletePaymentMethod: deletePayementMethodController,
  deleteManyPaymentMethod: deleteManyMethodsController,
  updatePaymentMethod: updatepaymentMethodController,
  getPaymentMethods: getAllPayementMethodsController,
  getAllOrders: allOrdersController,
  deleteManyOrders: deleteManyOrdersController,
  getAllNotifications: getAllNotificationsController,
  getVendorOrders: getVendorOrdersController,
};

export function getAdminApiRouter(
  controllers: {
    createCategory: ControllerType;
    deleteCategory: ControllerType;
    deleteManyCategories: ControllerType;
    getCategories: ControllerType;
    updateCategory: ControllerType;
    createPaymentMethod: ControllerType;
    deletePaymentMethod: ControllerType;
    deleteManyPaymentMethod: ControllerType;
    getPaymentMethods: ControllerType;
    updatePaymentMethod: ControllerType;
    getAllOrders: ControllerType;
    deleteManyOrders: ControllerType;
    getAllNotifications: ControllerType;
    getVendorOrders: ControllerType;
  } = defaults
) {
  router.use(isAuthentictedMiddleware);

  router
    .route("/categories")
    .post(restrictToMiddleware("admin"), controllers.createCategory) // create a category (only for admin)
    .get(controllers.getCategories) // get all categories 
    .delete(restrictToMiddleware("admin"), controllers.deleteManyCategories); // delete many categories (only for admin or vendor)

  router
    .route("/categories/:categoryId")
    .patch(restrictToMiddleware("admin"), controllers.updateCategory) // update a category (only for admin)
    .delete(restrictToMiddleware("admin"), controllers.deleteCategory); // delete a category (only for admin)

  router
    .route("/payment-methods")
    .post(restrictToMiddleware("admin"), controllers.createPaymentMethod) // create a payment method (only for admin)
    .get(
      restrictToMiddleware("admin", "vendor", "user"),
      controllers.getPaymentMethods
    ) // get payment methods (only for admin or vendor)
    .delete(restrictToMiddleware("admin"), controllers.deleteManyPaymentMethod);

  router
    .route("/payment-methods/:id")
    .delete(restrictToMiddleware("admin"), controllers.deletePaymentMethod) // delete payment method (only for admin)
    .patch(
      restrictToMiddleware("admin", "vendor"),
      controllers.updatePaymentMethod
    );

  router
    .route("/orders")
    .get(restrictToMiddleware("admin"), controllers.getAllOrders)
    .delete(controllers.deleteManyOrders);

  router
    .route("/vendorOrders")
    .get(restrictToMiddleware("vendor"), controllers.getVendorOrders);

  router
    .route("/notifications")
    .get(restrictToMiddleware("admin"), controllers.getAllNotifications);

  return router;
}
