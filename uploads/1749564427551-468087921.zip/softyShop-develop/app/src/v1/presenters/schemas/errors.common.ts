export enum ZodValidationMessageCommon {
  FIELDS_UNEXPECTED_MESSAGE = 'Unexpected Fields',
}
