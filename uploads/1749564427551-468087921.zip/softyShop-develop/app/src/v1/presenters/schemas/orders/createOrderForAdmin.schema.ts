import { z } from "zod";

const productSchema = z.object({
  productId: z.string().min(1, {
    message: "Product ID is required",
  }),
  quantity: z.number().int().min(0, {
    message: "Quantity must be a positive integer",
  }),
});

const createProductSchema = z.object({
  userId: z.string().min(1, {
    message: "The userId is required",
  }),
  addressId: z.string().min(1, {
    message: "The addressId is required",
  }),
  paymentMethodId: z.string().min(1, {
    message: "The paymentMethodId is required",
  }),
  products: z.array(productSchema),
});

export default createProductSchema;
