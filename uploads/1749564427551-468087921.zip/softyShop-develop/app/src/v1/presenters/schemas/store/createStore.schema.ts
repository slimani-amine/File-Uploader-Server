import { z } from "zod";

const createStoreSchema = z.object({
  name: z.string().min(4, {
    message: "Store name is required",
  }),
  phoneNumber: z
    .string()
    .min(8, {
      message: "Store phone number is required (8 digits)",
    })
    .max(8, {
      message: "Store phone number is required (8 digits)",
    }),
  logo: z.string().min(1, {
    message: "Store logo is required",
  }),
  cover: z.string().min(1, {
    message: "Store cover image is required",
  }),
  isPublished: z.boolean().optional(),
  location: z.array(z.number()).refine((data) => data.length === 2, {
    message: "Store location is required and must contain exactly two numbers",
  }),
  address: z.string().min(4, {
    message: "Store address is required",
  }),
  socialMediaLinks: z.array(z.string()),
  vendor_id: z.string().min(1, {
    message: "Store user ID is required",
  }),
});

export default createStoreSchema;
