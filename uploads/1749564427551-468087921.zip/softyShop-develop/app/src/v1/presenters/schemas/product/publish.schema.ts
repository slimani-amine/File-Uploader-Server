import { z } from "zod";
import { ZodValidationMessageCommon } from "../errors.common";

const publishProductSchema = z
  .object({
    isPublished: z.boolean().refine((value) => value !== undefined, {
      message:
        "Product publication status must be a boolean value (true or false)",
    }),
  })
  .strict(`${ZodValidationMessageCommon.FIELDS_UNEXPECTED_MESSAGE}`);

export default publishProductSchema;
