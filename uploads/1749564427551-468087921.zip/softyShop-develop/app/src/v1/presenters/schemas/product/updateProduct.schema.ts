import { z } from "zod";
import { ZodValidationMessageCommon } from "../errors.common";

const updateProductSchema = z
  .object({
    name: z.union([
      z.string().min(2, {
        message: "Product name must be a string with at least 2 characters",
      }),
      z.undefined(),
    ]),
    initialPrice: z.number(),
    description: z.union([
      z.string().min(2, {
        message:
          "Product description must be a string with at least 2 characters",
      }),
      z.undefined(),
    ]),

    price: z.union([
      z.number().min(0, {
        message:
          "The price of the product should be greater than or equal to 0s",
      }),
      z.undefined(),
    ]),
    stockNumber: z.union([
      z.number().min(0, {
        message:
          "The stock number of the product should be greater than or equal to 0",
      }),
      z.undefined(),
    ]),
    brand_id: z.union([
      z.string().min(1, {
        message: "Brand ID must be a string with at least 1 character",
      }),
      z.undefined(),
    ]),
    category_id: z.union([
      z.string().min(1, {
        message: "Category ID must be a string with at least 1 character",
      }),
      z.undefined(),
    ]),
    creator_id: z.union([
      z.string().min(1, {
        message: "Creator ID must be a string with at least 1 character",
      }),
      z.undefined(),
    ]),
    discount: z.union([
      z
        .number()
        .min(0, {
          message:
            "The stock number of the product should be greater than or equal to 0",
        })
        .max(100, {
          message:
            "The stock number of the product should be less than or equal to 100",
        }),
      z.undefined(),
    ]),
    images: z.union([z.array(z.string()),z.undefined(),]),
  })
  .strict(`${ZodValidationMessageCommon.FIELDS_UNEXPECTED_MESSAGE}`)
  .refine(
    (data) =>
      data?.name ||
      data?.brand_id ||
      data?.creator_id ||
      data?.initialPrice ||
      data?.description ||
      data?.category_id ||
      data?.discount ||
      data?.price ||
      data?.images ||
      data?.initialPrice ||
      data?.stockNumber,
    {
      message: "At least one field should be provided for updating the profile",
    }
  );

export default updateProductSchema;
