import { z } from "zod";

const createProductSchema = z.object({
  addressId: z.string().min(1, {
    message: "The addressId is required",
  }),
  paymentMethodId: z.string().min(1, {
    message: "The paymentMethodId is required",
  }),
});

export default createProductSchema;
