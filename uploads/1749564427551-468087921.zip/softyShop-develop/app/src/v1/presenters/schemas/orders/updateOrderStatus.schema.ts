import { z } from "zod";

const updateOrderStatusSchema = z.object({
  status: z.enum(
    ["processing", "on_delivery", "delivered", "cancelled"],

    {
      errorMap: (issue, ctx) => ({
        message:
          "status should be processing / on_delivery / delivered or cancelled ",
      }),
    }
  ),
});

export default updateOrderStatusSchema;
