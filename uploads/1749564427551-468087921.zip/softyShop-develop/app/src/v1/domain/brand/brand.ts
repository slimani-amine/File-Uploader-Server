import { IIdAsNumber, NumberId } from "../types/idAsNumber";

export interface IBrand extends IIdAsNumber {
  id: string;
  name: string;
  logo: string;
}

export class Brand extends NumberId implements IBrand {
  id: string;
  name: string;
  logo: string;

  constructor(payload: {
    id: string;
    name: string;
    logo: string;
  }) {
    super(payload.id);
    this.name = payload.name;
    this.logo = payload.logo;
  }
}

export interface ICreateBrandInput {
  name: string;
  logo: string;
}
