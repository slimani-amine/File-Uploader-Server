export const UNKNOWN_MAILING_ERROR_MESSAGE =
  'Error Occured While Sending The Email, Please Attempt Later';
