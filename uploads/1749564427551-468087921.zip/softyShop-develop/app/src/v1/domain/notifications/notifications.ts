import { IOrder } from "../order/order";
import { IStore } from "../store/store";
import { IIdAsNumber, NumberId } from "../types/idAsNumber";
import { IUser } from "../users/user";

export interface INotification extends IIdAsNumber {
  id: string;
  message: string;
  user?: IUser;
  order?: IOrder;
  store?: IStore;
}

export class Notification extends NumberId implements INotification {
  id: string;
  message: string;
  user?: IUser;
  order?: IOrder;
  store?: IStore;

  constructor(payload: {
    id: string;
    message: string;
    user?: IUser;
    order?: IOrder;
    store?: IStore;
  }) {
    super(payload.id);
    this.message = payload.message;
    this.user = payload.user;
    this.order = payload.order;
    this.store = payload.store;
  }
}

export interface ICreateNotificationInput {
  message: string;
  user_id?: string;
  order_id?: string;
  store_id?: string;
}
