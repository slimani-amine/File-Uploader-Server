import { IStore } from "../store/store";
import { IIdAsNumber, NumberId } from "../types/idAsNumber";

export interface IProductCreator extends IIdAsNumber {
  id: string;
  name: string;
}

export class ProductCreator extends NumberId implements IProductCreator {
  id: string;
  name: string;

  constructor(payload: { id: string; name: string; store?: IStore }) {
    super(payload.id);
    this.name = payload.name;
  }
}

export interface ICreateProductCreatorInput {
  name: string;
}
