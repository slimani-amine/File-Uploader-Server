import { IAddress } from "../addresses/addresses";
import { ICart } from "../cart/cart";
import { IPaymentMethod } from "../paymentMethod/paymentMethod";
import { IIdAsNumber, NumberId } from "../types/idAsNumber";

export interface IOrder extends IIdAsNumber {
  id: string;
  phoneNumber?: string;
  estimatedDeliveryDate: Date;
  status: string;
  isPaied?: boolean;
  paymentMethod?: IPaymentMethod;
  address?: IAddress;
  cart?: ICart;
  totalQuantity: number;
  totalAmount: number;
}

export class Order extends NumberId implements IOrder {
  id: string;
  phoneNumber?: string;
  estimatedDeliveryDate: Date;
  status: string;
  isPaied?: boolean;
  paymentMethod?: IPaymentMethod;
  address?: IAddress;
  cart?: ICart;
  totalQuantity: number;
  totalAmount: number;

  constructor(payload: {
    id: string;
    phoneNumber?: string;
    estimatedDeliveryDate: Date;
    status: string;
    isPaied?: boolean;
    paymentMethod?: IPaymentMethod;
    address?: IAddress;
    cart?: ICart;
    totalQuantity: number;
    totalAmount: number;
  }) {
    super(payload.id);
    this.phoneNumber = payload.phoneNumber;
    this.estimatedDeliveryDate = payload.estimatedDeliveryDate;
    this.status = payload.status;
    this.isPaied = payload.isPaied;
    this.paymentMethod = payload.paymentMethod;
    this.address = payload.address;
    this.cart = payload.cart;
    this.totalQuantity = payload.totalQuantity;
    this.totalAmount = payload.totalAmount;
  }
}

export interface ICreateOrderInput {
  phoneNumber?: string;
  paymentMethod_id?: string;
  address_id?: string;
  cartId: string;
  userId: string;
  totalQuantity: number;
  totalAmount: number;
}
