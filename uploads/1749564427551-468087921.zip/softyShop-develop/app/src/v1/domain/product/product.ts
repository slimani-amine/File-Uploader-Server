import { CategoryEntity } from "../../data/orm_models/category.entity";
import { IBrand } from "../brand/brand";
import { ICartProduct } from "../cartProduct/cartProduct";
import { IProductCreator } from "../productCreator/productCreator";
import { IReview } from "../reviews/reviews";
import { IStore } from "../store/store";
import { IIdAsNumber, NumberId } from "../types/idAsNumber";
import { IWishlist } from "../wishlist/wishlist";

export interface IProduct extends IIdAsNumber {
  id: string;
  name: string;
  initialPrice: number;
  price: number;
  stockNumber: number;
  publishedAt: Date;
  availability: boolean;
  isPublished: boolean;
  description: string;
  similar: string;
  creator?: IProductCreator;
  brand?: IBrand;
  reviews?: IReview[];
  wishlist?: IWishlist[];
  cartProducts?: ICartProduct[];
  store?: IStore;
  category?: CategoryEntity;
  images?: string;
  discount?: number;
}

export class Product extends NumberId implements IProduct {
  id: string;
  name: string;
  initialPrice: number;
  price: number;
  stockNumber: number;
  publishedAt: Date;
  availability: boolean;
  isPublished: boolean;
  description: string;
  similar: string;
  creator?: IProductCreator;
  brand?: IBrand;
  reviews?: IReview[];
  wishlist?: IWishlist[];
  cartProducts?: ICartProduct[];
  store?: IStore;
  category?: CategoryEntity;
  images?: string;
  discount?: number;

  constructor(payload: {
    id: string;
    name: string;
    initialPrice: number;
    price: number;
    stockNumber: number;
    publishedAt: Date;
    availability: boolean;
    isPublished: boolean;
    description: string;
    similar: string;
    creator?: IProductCreator;
    brand?: IBrand;
    reviews?: IReview[];
    wishlist?: IWishlist[];
    cartProducts?: ICartProduct[];
    store?: IStore;
    category?: CategoryEntity;
    images?: string;
    discount?: number;
  }) {
    super(payload.id);
    this.name = payload.name;
    this.price = payload.price;
    this.initialPrice = payload.initialPrice;
    this.stockNumber = payload.stockNumber;
    this.publishedAt = payload.publishedAt;
    this.availability = payload.availability;
    this.isPublished = payload.isPublished;
    this.description = payload.description;
    this.similar = payload.similar;
    this.creator = payload.creator;
    this.brand = payload.brand;
    this.reviews = payload.reviews || [];
    this.wishlist = payload.wishlist || [];
    this.cartProducts = payload.cartProducts || [];
    this.store = payload.store;
    this.category = payload.category;
    this.images = payload.images;
    this.discount = payload.discount;
  }
}

export interface ICreateProductInput {
  name: string;
  price: number;
  initialPrice: number;
  stockNumber: number;
  publishedAt: Date;
  availability: boolean;
  isPublished: boolean;
  description: string;
  similar: string;
  creator_id?: string;
  brand_id?: string;
  reviewIds?: string[];
  wishlistIds?: string[];
  cartProductIds?: string[];
  store_id?: string;
  category_id?: string;
  images?: string;
  discount?: number;
}
