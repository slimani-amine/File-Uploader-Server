export interface ILoginPayload {
  password: string;
  email: string;
}
