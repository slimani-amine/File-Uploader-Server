import { GOOGLE_CLIENT_ID } from "../../../../src/config/index";
import { exceptionService } from "../../core/errors/exceptions";
import { logger } from "../../core/logger/logger";
import { cartRepo } from "../../data/repositories/cart.repsitory";
import {
  IUsersRepository,
  usersRepo,
} from "../../data/repositories/users.repository";
import { ICreateUserInput, IUser } from "../../domain/users/user";
import {
  CreateUserTokensUseCaseType,
  createUserTokensUseCase,
} from "./createUserTokens.usecase";
import {OAuth2Client} from "google-auth-library"

const client = new OAuth2Client(GOOGLE_CLIENT_ID);

export type LoginWithGoogleUseCaseType = (
  googleToken: string
) => Promise<{ user: IUser; accessToken: string; refreshToken: string }>;

export const loginWithGoogleUseCaseBase =
  (dependencies: {
    usersRepo: IUsersRepository;
    createUserTokensUseCase: CreateUserTokensUseCaseType;
  }) =>
  async (googleToken: string) => {
    const ticket = await client.verifyIdToken({
      idToken: googleToken,
      audience: GOOGLE_CLIENT_ID,
    });

    const payload = ticket.getPayload();
    if (!payload) {
      exceptionService.badRequestException({
        message: "Invalid Google token",
      });
    }

    const { email, sub: googleId, name, picture } = payload;

    let userFound = await dependencies.usersRepo.findOne({
      where: { email },
    });

    if (!userFound) {
      const newCart = await cartRepo.createCart();

      const newUser: ICreateUserInput = {
        id: googleId,
        email,
        isVerified: true,
        picture,
        firstName: name || "",
        lastName: "",
        role: "vendor",
        confirmed_email: true,
        cart_id: newCart?.id,
      };
      userFound = await dependencies.usersRepo.create(newUser);
    }
    logger.log("LOGIN WITH GOOGLE USE CASE", JSON.stringify(userFound));
    const tokens = await dependencies.createUserTokensUseCase(userFound);

    return {
      user: userFound,
      ...tokens,
    };
  };

export const loginWithGoogleUseCase: LoginWithGoogleUseCaseType =
  loginWithGoogleUseCaseBase({
    usersRepo,
    createUserTokensUseCase,
  });
