export interface IRequestUser extends Express.User {}
