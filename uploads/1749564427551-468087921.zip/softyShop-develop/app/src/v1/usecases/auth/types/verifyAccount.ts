export interface IVerifyAccountInput {
  code: string;
}
