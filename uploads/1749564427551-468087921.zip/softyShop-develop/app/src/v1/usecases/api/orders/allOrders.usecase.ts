import {
  IOrderRepository,
  orderRepo,
} from "../../../data/repositories/orders.repository";
import { ILike } from "typeorm";

export type allOrdersUseCaseType = (
  queryParams: { [key: string]: any },
  pagination: { page: number; perPage: number }
) => Promise<any>;

export const allOrdersUseCaseBase =
  (
    dependencies: {
      orderRepo: IOrderRepository;
    } = {
      orderRepo: orderRepo,
    }
  ): allOrdersUseCaseType =>
  async (queryParams: { [key: string]: any }, pagination) => {
    const skip = (pagination.page - 1) * pagination.perPage;

    const whereCondition: any = {};
    if (queryParams.phoneNumber) {
      whereCondition.phoneNumber = ILike(`%${queryParams.phoneNumber}%`);
    }

    const orders = await dependencies.orderRepo.findAll({
      relations: {
        cart: {
          cartProducts: {
            product: {
              store: true,
            },
          },
        },
      },
      where: whereCondition,
      select: {
        cart: {
          id: true,
          totalAmount: true,
          totalQuantity: true,
          cartProducts: {
            id: true,
            product: {
              id: true,
              name: true,
              price: true,
              store: {
                id: true,
                name: true,
              },
            },
          },
        },
      },
      skip,
      take: pagination.perPage,
      order: {
        createdAt: "DESC",
      },
    });

    const totalRecords = await dependencies.orderRepo.count(whereCondition);
    return { orders, totalRecords };
  };

export const allOrdersUseCase: allOrdersUseCaseType = allOrdersUseCaseBase({
  orderRepo,
});
