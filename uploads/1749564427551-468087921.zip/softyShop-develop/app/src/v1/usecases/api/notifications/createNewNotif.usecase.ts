import { orderRepo } from "../../../data/repositories/orders.repository";
import {
  INotificationRepository,
  notificationRepo,
} from "../../../data/repositories/notifications.repository";
import {
  ICreateNotificationInput,
  INotification,
} from "../../../domain/notifications/notifications";
import { cartProductRepo } from "../../../data/repositories/cartProduct.repository";
import { storeRepo } from "../../../data/repositories/store.repository";
import { exceptionService } from "../../../core/errors/exceptions";

export type createNewNotifUseCaseType = (
  payload: ICreateNotificationInput
) => Promise<{ notification: INotification }>;

export const createNewNotifUseCaseBase =
  (
    dependencies: {
      notificationRepo: INotificationRepository;
    } = {
      notificationRepo: notificationRepo,
    }
  ): createNewNotifUseCaseType =>
  async (payload: ICreateNotificationInput) => {
    const order = await orderRepo.findOne({
      relations: {
        cart: true,
      },
      where: { id: payload.order_id },
      select: {
        cart: {
          id: true,
        },
      },
    });

    if (!order) {
      exceptionService.notFoundException({
        message: "Order not found",
      });
    }

    const cartId = order?.cart.id;

    const cart = await cartProductRepo.findOne({
      relations: {
        product: {
          store: true,
        },
      },
      where: { cart: { id: cartId } },
    });

    if (!cart) {
      exceptionService.notFoundException({
        message: "Cart not found",
      });
    }

    const productId = cart?.product.id;

    const store = await storeRepo.findOne({
      relations: {
        products: true,
      },
      where: { products: { id: productId } },
    });

    if (!store) {
      exceptionService.notFoundException({
        message: "Store not found",
      });
    }

    const notificationCreated =
      await dependencies.notificationRepo.createNotification({
        message: payload.message,
        user_id: payload.user_id,
        order_id: payload.order_id,
        store_id: store.id,
      });

    return {
      notification: notificationCreated,
    };
  };

export const createNewNotifUseCase: createNewNotifUseCaseType =
  createNewNotifUseCaseBase({
    notificationRepo,
  });
