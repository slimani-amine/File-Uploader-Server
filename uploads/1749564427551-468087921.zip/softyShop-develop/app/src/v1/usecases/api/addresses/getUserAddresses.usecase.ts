import { IAddress } from "../../../domain/addresses/addresses";
import { exceptionService } from "../../../core/errors/exceptions";
import { usersRepo } from "../../../data/repositories/users.repository";
import { IUser } from "../../../domain/users/user";
import {
  IAddressRepository,
  addressRepo,
} from "../../../data/repositories/addresses.repository";

export type GetUserAddressesUseCaseType = (
  userId: string,
  pagination: { page: number; perPage: number }
) => Promise<{ addresses: IAddress[]; totalRecords: number }>;


export const getUserAddressesUseCaseBase =
  (dependencies: { addressRepo: IAddressRepository }={
    addressRepo: addressRepo,
  }):GetUserAddressesUseCaseType =>
  async (userId, pagination) => {

    const user = (await usersRepo.findOne({
      where: { id: userId },
    })) as IUser;

    if (!user) {
      exceptionService.notFoundException({
        message: "User not found",
      });
    }
    const skip = (pagination.page - 1) * pagination.perPage;

    const addressesFound = await dependencies.addressRepo.findMyAddresses({
      where: { user: { id: userId } },
      order: {
        id: "DESC",
      },
      skip,
      take: pagination.perPage,
    });

    const totalRecords = await dependencies.addressRepo.count({
      user: {
        id: userId,
      },
    });
    return { addresses: addressesFound, totalRecords };
  };

export const getUserAddressesUseCase = getUserAddressesUseCaseBase({
  addressRepo: addressRepo,
});
