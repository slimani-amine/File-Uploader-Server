import { cartRepo } from "../../../data/repositories/cart.repsitory";
import {
  ICartProductRepository,
  cartProductRepo,
} from "../../../data/repositories/cartProduct.repository";
import { ICart } from "../../../domain/cart/cart";
import { CartProductEntity } from "../../../data/orm_models/cartProduct.entity";

export type getUserCartProductsByIdUseCaseType = (queryParams: {
  cartId: string;
}) => Promise<(CartProductEntity[] | ICart)[]>;

export const getUserCartProductsByIdUseCaseBase =
  (dependencies: { cartProductRepo: ICartProductRepository }) =>
  async (queryParams: {
    cartId: string;
  }): Promise<(CartProductEntity[] | ICart)[]> => {
    const { cartId } = queryParams;

    const cartProduct = await dependencies.cartProductRepo.findAll({
      relations: {
        product: true,
      },
      where: {
        cart: { id: cartId },
      },
    });

    let sumQuantities = 0;
    for (let i = 0; i < cartProduct.length; i++) {
      sumQuantities += cartProduct[i].quantity;
    }
    let sumPrice = 0;
    for (let i = 0; i < cartProduct.length; i++) {
      sumPrice +=
        cartProduct[i].product.price * 1 * cartProduct[i].quantity * 1;
    }

    const cart = (await cartRepo.findOne({
      where: {
        id: cartId.toString(),
      },
    })) as any;

    const newCart = await cartRepo.updateCart(cart, {
      totalQuantity: sumQuantities,
      totalAmount: sumPrice,
    });

    return [newCart, cartProduct];
  };

export const getUserCartProductsByIdUseCase =
  getUserCartProductsByIdUseCaseBase({
    cartProductRepo: cartProductRepo,
  });
