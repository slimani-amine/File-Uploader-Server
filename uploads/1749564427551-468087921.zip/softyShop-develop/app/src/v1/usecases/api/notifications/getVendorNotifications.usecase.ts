import {
  INotificationRepository,
  notificationRepo,
} from "../../../data/repositories/notifications.repository";
import { storeRepo } from "../../../data/repositories/store.repository";

export type getVendorNotificationsUseCaseType = (
  vendorId: string
) => Promise<any[]>;

export const getVendorNotificationsUseCaseBase =
  (dependencies: { notificationRepo: INotificationRepository }) =>
  async (vendorId: string) => {
    try {
      const vendorStores = await storeRepo.findAll({
        where: { user: { id: vendorId } },
      });
      
      const storeNotificationsPromises = vendorStores.map(async (store) => {
        const notifications = await dependencies.notificationRepo.findAll({
          relations: { user: true, order: { cart: true } },
          where: { store: { id: store.id } },
          select: {
            id: true,
            message: true,
            user: {
              firstName: true,
              lastName: true,
              email: true,
              phoneNumber: true,
            },
            order: {
              id: true,
              status: true,
              isPaied: true,
              cart: {
                totalAmount: true,
                totalQuantity: true,
              },
            },
          },
        });
        return notifications;
      });
      
      const storeNotifications = await Promise.all(storeNotificationsPromises);
      
      const allNotifications = storeNotifications.flat();
      
      return allNotifications;
    } catch (error) {
      console.error("Error fetching vendor notifications:", error);
      throw error;
    }
  };

export const getVendorNotificationsUseCase = getVendorNotificationsUseCaseBase({
  notificationRepo: notificationRepo,
});
