import {
  IProductRepository,
  productRepo,
} from "../../../data/repositories/product.repository";
import { Between, ILike, In, MoreThan, Equal } from "typeorm";

export type GetAllProductUseCaseType = (
  queryParams: { [key: string]: any },
  pagination: { page: number; perPage: number }
) => Promise<any>;

export const getAllProductUseCaseBase =
  (dependencies: {
    productRepo: IProductRepository;
  }): GetAllProductUseCaseType =>
  async (queryParams: { [key: string]: any }, pagination) => {
    console.log("🚀 ~ queryParams:", queryParams);
    const skip = (pagination?.page - 1) * pagination?.perPage;

    const whereCondition: any = {};

    if (queryParams.isPublished) {
      whereCondition.isPublished = true;
      whereCondition.store = {
        isPublished: true,
      };
    }

    if (queryParams.name) {
      whereCondition.name = ILike(`%${queryParams.name}%`);
    }

    if (queryParams.category_id) {
      whereCondition.category = { id: queryParams.category_id };
    }

    if (queryParams.onSale !== undefined ) {
      whereCondition.discount = MoreThan(0);
    }

    if (queryParams.inStock !== undefined && queryParams.inStock !== 'false') {
      whereCondition.stockNumber = MoreThan(0);
    }

    if (queryParams.brand_ids) {
      const brandIdsString = queryParams.brand_ids;
      const brandIdsArray = Array.isArray(brandIdsString)
        ? brandIdsString.map((id) => parseInt(id.trim()))
        : [parseInt(brandIdsString)];

      if (brandIdsArray.length > 0) {
        whereCondition.brand = { id: In(brandIdsArray) };
      }
    }

    if (queryParams.priceCeiling && queryParams.priceFloor) {
      whereCondition.price = Between(
        queryParams.priceFloor,
        queryParams.priceCeiling
      );
    }
    console.log("🚀 ~ whereCondition:", whereCondition);

    const productsFound = pagination
      ? await dependencies.productRepo.findAll({
          relations: {
            creator: true,
            brand: true,
            reviews: true,
            category: true,
            store: true,
          },
          where: whereCondition,
          select: {
            creator: {
              id: true,
              name: true,
            },
            brand: {
              id: true,
              name: true,
            },
            category: {
              id: true,
              name: true,
            },
            store: {
              id: true,
              name: true,
            },
            reviews: {
              rating: true,
            },
          },
          skip,
          take: pagination?.perPage,
          order: {
            id: "DESC",
          },
        })
      : await dependencies.productRepo.findAll({
          relations: {
            creator: true,
            brand: true,
            reviews: true,
            category: true,
            store: true,
          },
          where: whereCondition,
          select: {
            creator: {
              id: true,
              name: true,
            },
            brand: {
              id: true,
              name: true,
            },
            category: {
              id: true,
              name: true,
            },
            store: {
              id: true,
              name: true,
            },
            reviews: {
              rating: true,
            },
          },
          order: {
            id: "DESC",
          },
        });
    console.log("🚀 ~ productsFound:", productsFound);

    const totalRecords = await dependencies.productRepo.count(whereCondition);
    return { productsFound, totalRecords };
  };

export const getAllProductsUseCase = getAllProductUseCaseBase({
  productRepo: productRepo,
});
