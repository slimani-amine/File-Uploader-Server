import { ICreateOrderInput, IOrder } from "../../../domain/order/order";
import {
  IOrderRepository,
  orderRepo,
} from "../../../data/repositories/orders.repository";
import { cartProductRepo } from "../../../data/repositories/cartProduct.repository";

export type createOrderUseCaseType = (payload: {
  userId: string;
  cartId: string;
  phoneNumber?: string;
  paymentMethodId?: string;
  addressId?: string;
}) => Promise<{ orders: Record<string, IOrder> }>;

export const createOrderUseCaseBase =
  (dependencies: { orderRepo: IOrderRepository }): createOrderUseCaseType =>
  async (payload) => {
    const { userId, cartId } = payload;

    try {
      const cartProducts = await cartProductRepo.findAll({
        relations: {
          product: {
            store: true,
          },
        },
        where: {
          cart: { id: cartId },
        },
      });

      if (!cartProducts || cartProducts.length === 0) {
        throw new Error("Cart not found or empty");
      }

      const orders: Record<string, IOrder> = {};

      // Group products by store
      const productsByStore: Record<
        string,
        { quantity: number; amount: number }[]
      > = {};
      cartProducts.forEach((cartProduct) => {
        const storeId = cartProduct?.product?.store?.id;
        if (!productsByStore[storeId]) {
          productsByStore[storeId] = [];
        }
        productsByStore[storeId].push({
          quantity: cartProduct?.quantity,
          amount: cartProduct?.quantity * cartProduct?.product?.price, // Calculate the amount
        });
      });

      // Create order for each store
      for (const storeId in productsByStore) {
        const storeProducts = productsByStore[storeId];

        // Calculate total quantity and amount for the store
        const totalQuantity = storeProducts.reduce(
          (total, product) => total + product.quantity,
          0
        );
        const totalAmount = storeProducts.reduce(
          (total, product) => total + product.amount,
          0
        );

        // Prepare order input
        const orderInput: ICreateOrderInput = {
          userId,
          cartId,
          phoneNumber: payload.phoneNumber,
          paymentMethod_id: payload.paymentMethodId,
          address_id: payload.addressId,
          totalQuantity,
          totalAmount,
        };

        // Create the order
        const orderCreated =
          await dependencies.orderRepo.createOrder(orderInput);
        orders[storeId] = orderCreated;
      }

      return { orders };
    } catch (error) {
      throw error;
    }
  };

export const createOrderUseCase: createOrderUseCaseType =
  createOrderUseCaseBase({
    orderRepo,
  });
