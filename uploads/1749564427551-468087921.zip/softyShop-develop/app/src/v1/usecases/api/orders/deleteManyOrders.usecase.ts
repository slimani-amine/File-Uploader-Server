import { exceptionService } from "../../../core/errors/exceptions";
import {
  IOrderRepository,
  orderRepo,
} from "../../../data/repositories/orders.repository";

export type DeleteManyOrdersUseCaseType = (ids: number[]) => Promise<number>;

export const deleteManyOrdersUseCaseBase =
  (dependencies: { orderRepo: IOrderRepository }) =>
  async (ids: number[]) => {
    const ordersFound = await dependencies.orderRepo.deleteMany(ids);

    if (ordersFound === 0) {
      exceptionService.notFoundException({
        message: "Orders not found",
      });
    }

    return ordersFound;
  };

export const deleteManyOrdersUseCase = deleteManyOrdersUseCaseBase({
  orderRepo: orderRepo,
});
