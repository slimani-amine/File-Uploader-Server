import { INotification } from "../../../domain/notifications/notifications";
import {
  INotificationRepository,
  notificationRepo,
} from "../../../data/repositories/notifications.repository";

export type getAllNotificationsUseCaseType = () => Promise<INotification[]>;

export const getAllNotificationsUseCaseBase =
  (dependencies: { notificationRepo: INotificationRepository }) => async () => {
    const storesFound = await dependencies.notificationRepo.findAll({
      relations: {
        user: true,
        order: {
          cart: {
            cartProducts: {
              product: {
                store: true,
              },
            },
          },
        },
      },
      select: {
        id: true,
        message: true,
        user: { id: true, email: true },
        order: {
          id: true,
          status: true,
          isPaied: true,
          cart: {
            totalAmount: true,
            totalQuantity: true,
            cartProducts: {
              product: {
                store: {
                  id: true,
                },
              },
            },
          },
        },
      },
    });

    return storesFound;
  };

export const getAllNotificationsUseCase = getAllNotificationsUseCaseBase({
  notificationRepo: notificationRepo,
});
