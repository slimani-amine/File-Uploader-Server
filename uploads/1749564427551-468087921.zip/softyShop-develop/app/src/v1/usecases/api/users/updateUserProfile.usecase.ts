import { ACCOUNT_NOT_FOUND_ERROR_MESSAGE } from "../../../domain/auth/errors";
import { exceptionService } from "../../../core/errors/exceptions";
import {
  IUsersRepository,
  usersRepo,
} from "../../../data/repositories/users.repository";
import { IUser } from "../../../domain/users/user";
import { IRequestUser } from "../../auth/types/IRequestUser";

export type UpdateUserProfileUseCaseType = (
  userId: string,
  payload: Partial<IUser>
) => Promise<IUser>;

export const updateUserProfileUseCaseBase =
  (dependencies: { usersRepo: IUsersRepository }) =>
  async (userId: string, payload: Partial<IUser>) => {
    const userFound = await dependencies.usersRepo.findOne({
      where: {
        id: userId,
      },
    });

    if (!userFound) {
      exceptionService.notFoundException({
        message: ACCOUNT_NOT_FOUND_ERROR_MESSAGE,
      });
    }

    const updatedUser = await dependencies.usersRepo.updateOne(userFound, {
      email: payload?.email || userFound.email,
      picture: payload?.picture || userFound.picture,
      firstName: payload?.firstName || userFound.firstName,
      lastName: payload?.lastName || userFound.lastName,
      phoneNumber: payload?.phoneNumber || userFound.phoneNumber
    });

    return updatedUser;
  };

export const updateUserProfileUseCase: UpdateUserProfileUseCaseType =
  updateUserProfileUseCaseBase({
    usersRepo: usersRepo,
  });
