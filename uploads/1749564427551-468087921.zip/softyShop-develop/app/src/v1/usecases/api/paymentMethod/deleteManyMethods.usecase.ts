import {
  IPaymentMethodRepository,
  paymentMethodRepo,
} from "../../../data/repositories/paymentMethod.repository";
import { exceptionService } from "../../../core/errors/exceptions";

export type DeleteManyMethodsUseCaseType = (ids: number[]) => Promise<number>;

export const deleteManyMethodsUseCaseBase =
  (dependencies: { paymentMethodRepo: IPaymentMethodRepository }) =>
  async (ids: number[]) => {
    const productCreatorsFound =
      await dependencies.paymentMethodRepo.deleteMany(ids);

    if (productCreatorsFound === 0) {
      exceptionService.notFoundException({
        message: "Methods not found",
      });
    }

    return productCreatorsFound;
  };

export const deleteManyMethodsUseCase = deleteManyMethodsUseCaseBase({
  paymentMethodRepo: paymentMethodRepo,
});
