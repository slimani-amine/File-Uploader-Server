import { QueryResult } from "../../../utils/querying/apiFeatures.util";
import {
  IProductCreatorRepository,
  productCreatorRepo,
} from "../../../data/repositories/productCreator.repository";
import { IProductCreator } from "../../../domain/productCreator/productCreator";

export type getAllProductCreatorsUseCaseType = (queryParams: {
  [key: string]: any;
}) => Promise<QueryResult<IProductCreator>>;

export const getAllProductCreatorsUseCaseBase =
  (dependencies: { productCreatorRepo: IProductCreatorRepository }) =>
  async (queryParams: { [key: string]: any }) => {
    const productCreatorsFound =
      await dependencies.productCreatorRepo.findByQuery(queryParams);

    return productCreatorsFound;
  };

export const getAllProductCreatorsUseCase = getAllProductCreatorsUseCaseBase({
  productCreatorRepo: productCreatorRepo,
});
