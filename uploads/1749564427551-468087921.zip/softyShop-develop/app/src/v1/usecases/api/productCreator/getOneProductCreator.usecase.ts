import {
  IProductCreatorRepository,
  productCreatorRepo,
} from "../../../data/repositories/productCreator.repository";
import { IProductCreator } from "../../../domain/productCreator/productCreator";

export type getOneProductCreatorUseCaseType = (
  productCreatorId: string
) => Promise<IProductCreator>;

export const getOneProductCreatorUseCaseBase =
  (dependencies: { productCreatorsRepo: IProductCreatorRepository }) =>
  async (productCreatorId: string) => {
    const productCreatorFound = await dependencies.productCreatorsRepo.findOne({
      where: { id: productCreatorId },
    });

    return productCreatorFound;
  };

export const getOneProductCreatorUseCase = getOneProductCreatorUseCaseBase({
  productCreatorsRepo: productCreatorRepo,
});
