import {
  INotificationRepository,
  notificationRepo,
} from "../../../data/repositories/notifications.repository";

export type getUserNotificationsUseCaseType = (
  userId: string
) => Promise<any[]>;

export const getUserNotificationsUseCaseBase =
  (dependencies: { notificationRepo: INotificationRepository }) =>
  async (userId: string) => {
    const notifications = await dependencies.notificationRepo.findAll({
      relations: { user: true, order: { cart: true } },
      where: { user: { id: userId } },
      select: {
        id: true,
        message: true,
        user: {
          firstName: true,
          lastName: true,
          email: true,
          phoneNumber: true,
        },
        order: {
          id: true,
          status: true,
          isPaied: true,
          cart: {
            totalAmount: true,
            totalQuantity: true,
          },
        },
      },
    });
    return notifications;
  };

export const getUserNotificationsUseCase = getUserNotificationsUseCaseBase({
  notificationRepo: notificationRepo,
});
