import { ICartProductRepository, cartProductRepo } from "../../../data/repositories/cartProduct.repository";
import { ICreateCartProductsInput } from "../../../domain/cartProduct/cartProduct";

export type AddManyProductsToCartUseCaseType = (
  payload: ICreateCartProductsInput
) => Promise<{ cartProducts: any }>;

export const addManyProductsToCartUseCaseBase = (
  dependencies: {
    cartProductRepo: ICartProductRepository;
  }
): AddManyProductsToCartUseCaseType => async (
  payload: ICreateCartProductsInput
) => {
  try {
    const cartProductsCreated = await Promise.all(
      (payload.cart || []).map(async (cartProduct) => {
        const cartProductCreated = await dependencies.cartProductRepo.createCartProduct({
          quantity: cartProduct.quantity,
          productId: cartProduct.productId,
          cartId: payload.cartId,
        });
        return cartProductCreated;
      })
    );
    return { cartProducts: cartProductsCreated };
  } catch (error) {
    throw error;
  }
};

export const addManyProductsToCartUseCase: AddManyProductsToCartUseCaseType =
  addManyProductsToCartUseCaseBase({ cartProductRepo });

