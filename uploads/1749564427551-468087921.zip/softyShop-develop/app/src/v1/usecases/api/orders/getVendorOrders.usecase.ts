import { IOrder } from "../../../domain/order/order";
import {
  IOrderRepository,
  orderRepo,
} from "../../../data/repositories/orders.repository";
import { cartProductRepo } from "../../../data/repositories/cartProduct.repository";

export type getVendorOrdersUseCaseType = (
  userId: string,
  queryParams: { [key: string]: any },
  pagination: { page: number; perPage: number }
) => Promise<{ orders: IOrder[]; totalRecords: number }>;

export const getVendorOrdersUseCaseBase =
  (
    dependencies: { orderRepo: IOrderRepository } = { orderRepo: orderRepo }
  ): getVendorOrdersUseCaseType =>
  async (userId, queryParams, pagination) => {
    const skip = (pagination.page - 1) * pagination.perPage;

    try {
      const allOrders = await dependencies.orderRepo.findAll({
        relations: {
          cart: true,
        },
        skip,
        take: pagination.perPage,
        order: {
          createdAt: "DESC",
        },
        select: {
          cart: {
            id: true,
            cartProducts: {
              id: true,
            },
          },
        },
      });

      // Filter orders by userId 
      const filteredOrders = await Promise.all(
        allOrders.map(async (order) => {
          const findCartProduct = await cartProductRepo.findAll({
            where: {
              cart: {
                id: order.cart.id,
              },
              product: {
                store: {
                  user: {
                    id: userId,
                  },
                },
              },
            },
          });
          if (findCartProduct.length > 0) {
            return order;
          }
        })
      );

      // Filter out undefined values
      const validOrders = filteredOrders.filter((order) => order !== undefined);

      // Count total records
      const totalRecords = validOrders.length;

      return { orders: validOrders, totalRecords };
    } catch (error) {
      console.error("Error fetching orders:", error);
      throw error;
    }
  };

// Create the use case with provided dependencies
export const getVendorOrdersUseCase: getVendorOrdersUseCaseType =
  getVendorOrdersUseCaseBase({ orderRepo });
