import {
  IBrandRepository,
  brandRepo,
} from "../../../data/repositories/brand.repository";
import { IBrand } from "../../../domain/brand/brand";

export type getOneBrandUseCaseType = (brandId: string) => Promise<IBrand>;

export const getOneBrandUseCaseBase =
  (dependencies: { brandsRepo: IBrandRepository }) =>
  async (brandId: string) => {
    const storesFound = await dependencies.brandsRepo.findOne({
      where: { id: brandId },
    });

    return storesFound;
  };

export const getOneBrandUseCase = getOneBrandUseCaseBase({
  brandsRepo: brandRepo,
});
