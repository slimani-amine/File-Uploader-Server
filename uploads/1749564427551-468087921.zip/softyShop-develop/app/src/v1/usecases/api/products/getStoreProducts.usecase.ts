import {
  IProductRepository,
  productRepo,
} from "../../../data/repositories/product.repository";
import { storeRepo } from "../../../data/repositories/store.repository";
import { exceptionService } from "../../../core/errors/exceptions";
import { Between, ILike, In, MoreThan } from "typeorm";

export type GetStoreProductUseCaseType = (
  storeId: string,
  queryParams: { [key: string]: any },
  pagination: { page: number; perPage: number }
) => Promise<any>;

export const getStoreProductUseCaseBase =
  (dependencies: { productRepo: IProductRepository }) =>
  async (storeId: string, queryParams: { [key: string]: any }, pagination) => {
    const skip = (pagination.page - 1) * pagination.perPage;
    const whereCondition: any = {
      store: {
        id: storeId,
      },
    };

    if (queryParams.name) {
      whereCondition.name = ILike(`%${queryParams.name}%`);
    }
    if (queryParams.isPublished) {
      whereCondition.isPublished = true;
    }
    if (queryParams.category_id) {
      whereCondition.category = { id: queryParams.category_id };
    }

    if (queryParams.onSale !== undefined) {
      whereCondition.discount = queryParams.onSale;
    }

    if (queryParams.inStock !== undefined) {
      if (queryParams.inStock) {
        whereCondition.stockNumber = MoreThan(0);
      } else {
        whereCondition.stockNumber = 0;
      }
    }
    if (queryParams.brand_ids) {
      const brandIdsString = queryParams.brand_ids;
      const brandIdsArray = Array.isArray(brandIdsString)
        ? brandIdsString.map((id) => parseInt(id.trim()))
        : [parseInt(brandIdsString)];

      if (brandIdsArray.length > 0) {
        whereCondition.brand = { id: In(brandIdsArray) };
      }
    }

    if (queryParams.priceCeiling && queryParams.priceFloor) {
      whereCondition.price = Between(
        queryParams.priceCeiling,
        queryParams.priceFloor
      );
    }

    const store = await storeRepo.findOne({
      where: { id: storeId },
    });
    if (!store) {
      exceptionService.notFoundException({
        message: "store not found",
      });
    }
    const productsFound = await dependencies.productRepo.findAll({
      where: whereCondition,
      relations: {
        store: true,
        reviews: true,
        category: true,
      },
      order: { createdAt: "DESC" },

      skip,
      take: pagination.perPage,
    });

    const totalRecords = await dependencies.productRepo.count(whereCondition);
    return { productsFound, totalRecords };
  };

export const getStoreProductUseCase = getStoreProductUseCaseBase({
  productRepo: productRepo,
});
