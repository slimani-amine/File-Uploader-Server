import { exceptionService } from "../../../core/errors/exceptions";
import {
  IBrandRepository,
  brandRepo,
} from "../../../data/repositories/brand.repository";

export type DeleteManyBrandsUseCaseType = (ids: number[]) => Promise<number>;

export const deleteManyBrandsUseCaseBase =
  (dependencies: { brandRepo: IBrandRepository }) => async (ids: number[]) => {
    const brandsFound = await dependencies.brandRepo.deleteMany(ids);

    if (brandsFound === 0) {
      exceptionService.notFoundException({
        message: "Brandss not found",
      });
    }

    return brandsFound;
  };

export const deleteManyBrandsUseCase = deleteManyBrandsUseCaseBase({
  brandRepo: brandRepo,
});
