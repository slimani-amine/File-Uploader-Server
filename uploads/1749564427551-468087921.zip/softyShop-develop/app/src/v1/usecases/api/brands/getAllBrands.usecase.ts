import { QueryResult } from "../../../utils/querying/apiFeatures.util";
import {
  IBrandRepository,
  brandRepo,
} from "../../../data/repositories/brand.repository";
import { IBrand } from "../../../domain/brand/brand";

export type getAllBrandsUseCaseType = (queryParams: {
  [key: string]: any;
}) => Promise<QueryResult<IBrand>>;

export const getAllBrandsUseCaseBase =
  (dependencies: { brandsRepo: IBrandRepository }) =>
  async (queryParams: { [key: string]: any }) => {
    const brandsFound = await dependencies.brandsRepo.findByQuery(queryParams);

    return brandsFound;
  };

export const getAllBrandsUseCase = getAllBrandsUseCaseBase({
  brandsRepo: brandRepo,
});
