import { ILike } from "typeorm";
import {
  IProductRepository,
  productRepo,
} from "../../../data/repositories/product.repository";

export type GetVendorProductUseCaseType = (
  vendorId: string,
  queryParams: { [key: string]: any },
  pagination: { page: number; perPage: number }
) => Promise<any>;

export const getVendorProductUseCaseBase =
  (dependencies: { productRepo: IProductRepository }) =>
  async (vendorId: string, queryParams: { [key: string]: any }, pagination) => {
    const skip = (pagination.page - 1) * pagination.perPage;
    const whereCondition: any = {
      store: {
        user: { id: vendorId },
      },
    };

    if (queryParams.name) {
      whereCondition.name = ILike(`%${queryParams?.name}%`);
    }
    
    const productsFound = await dependencies.productRepo.findAll({
      where: whereCondition,
      relations: {
        store: true,
        reviews: true,
        category: true,
      },
      
      skip,
      take: pagination.perPage,
    });

    const totalRecords = await dependencies.productRepo.count(whereCondition);
    return { productsFound, totalRecords };
  };

export const getVendorProductUseCase = getVendorProductUseCaseBase({
  productRepo: productRepo,
});
