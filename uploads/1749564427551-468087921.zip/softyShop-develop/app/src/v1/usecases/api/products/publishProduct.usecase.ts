import { IProductRepository } from "../../../data/repositories/product.repository";
import { productRepo } from "../../../data/repositories/product.repository";
import { IProduct } from "../../../domain/product/product";

export type PublishProductUseCaseType = (
  product: IProduct,
  updatePayload: Partial<IProduct>
) => Promise<IProduct>;

export const publishProductUseCaseBase =
  (productRepository: IProductRepository) =>
  async (product: IProduct, updatePayload: Partial<IProduct>) => {
    const updatedProduct = await productRepository.updateProduct(product, {
      isPublished: updatePayload.isPublished,
    });
    return updatedProduct;
  };

export const publishProductUseCase: PublishProductUseCaseType =
  publishProductUseCaseBase(productRepo);
