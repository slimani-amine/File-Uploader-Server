import {
  IProductRepository,
  productRepo,
} from "../../../data/repositories/product.repository";
import {
  IStoreRepository,
  storeRepo,
} from "../../../data/repositories/store.repository";
import {
  IOrderRepository,
  orderRepo,
} from "../../../data/repositories/orders.repository";
import {
  ICartProductRepository,
  cartProductRepo,
} from "../../../data/repositories/cartProduct.repository";
import { IOrder } from "app/src/v1/domain/order/order";
import { Between } from "typeorm";

export type allStoresStatsUseCaseType = (
  userId: string,
  startDate: string,
  endDate: string
) => Promise<any>;

export const allStoresStatsUseCaseBase =
  (dependencies: {
    storeRepo: IStoreRepository;
    productRepo: IProductRepository;
    orderRepo: IOrderRepository;
    cartProductRepo: ICartProductRepository;
  }) =>
  async (userId: string, startDate: string, endDate: string) => {
    const whereCondition: any = {};

    if (startDate && endDate) {
      whereCondition.createdAt = Between(
        new Date(startDate),
        new Date(endDate)
      );
    }

    const numberOfStores =
      (await dependencies.storeRepo.count({
        user: { id: userId },
      })) || 0;
    const numberOfProducts =
      (await dependencies.productRepo.count({
        store: { user: { id: userId } },
      })) || 0;

    const allOrders = await dependencies.orderRepo.findAll({
      relations: {
        cart: {
          cartProducts: {
            product: {
              store: true,
            },
          },
        },
      },
      select: {
        cart: {
          id: true,
          cartProducts: {
            product: {
              store: {
                id: true,
              },
            },
          },
        },
      },
      where: whereCondition, // Apply the date range filter
    });

    const filteredOrders = await Promise.all(
      allOrders.map(async (order) => {
        const findCartProduct = await dependencies.cartProductRepo.findAll({
          where: {
            cart: {
              id: order.cart.id,
            },
            product: {
              store: {
                user: {
                  id: userId,
                },
              },
            },
          },
        });
        if (findCartProduct.length > 0) {
          return order;
        }
      })
    );

    const validOrders = filteredOrders.filter((order) => order !== undefined);

    const numberofOrders = validOrders.length || 0;
    const StoreProfits =
      validOrders.reduce((acc: number, order: IOrder) => {
        if (order.status === "delivered") {
          return acc + order.totalAmount;
        }
        return acc;
      }, 0) || 0;


    // Count the number of orders for each status
    const orderStatusCounts: { [key: string]: number } = {};
    validOrders.forEach((order) => {
      const status = order.status;
      orderStatusCounts[status] = (orderStatusCounts[status] || 0) + 1;
    });

    // Calculate the percentage of each order status
    const orderStatusPercentages = Object.keys(orderStatusCounts).map(
      (status) => {
        return {
          name: status,
          percentage: (orderStatusCounts[status] / numberofOrders) * 100,
        };
      }
    );

    // Fetch the optionsOfStoresSelling data from the repository
    const stores = await storeRepo.findAll({ where: { user: { id: userId } } });
    const numberOfOrdersPromises = stores.map(async (store) => {
      const filteredOrders = await Promise.all(
        allOrders.map(async (order) => {
          const findCartProduct = await dependencies.cartProductRepo.findAll({
            where: {
              cart: {
                id: order.cart.id,
              },
              product: {
                store: {
                  id: store.id,
                },
              },
            },
          });

          if (findCartProduct.length > 0) {
            return order;
          }
          return;
        })
      );

      const validOrders = filteredOrders.filter((order) => order !== undefined);
      return validOrders.length;
    });

    const numberOfOrders = await Promise.all(numberOfOrdersPromises);
    const optionsOfStoresSelling = stores.map((store, index) => ({
      name: store.name,
      numberOfOrders: numberOfOrders[index],
    }));
    optionsOfStoresSelling.sort((a, b) => b.numberOfOrders - a.numberOfOrders);

    // Calculate the duration of the date range
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate);
    const duration = (endDateObj.getTime() - startDateObj.getTime()) / 4;

    // Initialize arrays to hold the profits and periods for each segment
    const dates: string[] = [];
    const profits: number[] = [];

    // Calculate the profits for each segment
    for (let i = 0; i < 4; i++) {
      const segmentStartDate = new Date(startDateObj.getTime() + i * duration);
      const segmentEndDate = new Date(
        startDateObj.getTime() + (i + 1) * duration
      );

      const segmentProfit = validOrders.reduce((acc, order) => {
        const orderDate = new Date(order.createdAt);
        if (
          order.status === "delivered" &&
          orderDate >= segmentStartDate &&
          orderDate < segmentEndDate
        ) {
          return acc + order.totalAmount;
        }
        return acc;
      }, 0);

      dates.push(
        `${segmentStartDate.toISOString()} - ${segmentEndDate.toISOString()}`
      );
      profits.push(segmentProfit);
    }
    const storeProfitsBySegment = [dates, profits];

    return {
      numberOfStores,
      numberOfProducts,
      numberofOrders,
      StoreProfits,
      storeProfitsBySegment,
      orderStatusPercentages,
      optionsOfStoresSelling,
    };
  };

export const allStoresStatsUseCase = allStoresStatsUseCaseBase({
  storeRepo: storeRepo,
  productRepo: productRepo,
  orderRepo: orderRepo,
  cartProductRepo: cartProductRepo,
});
