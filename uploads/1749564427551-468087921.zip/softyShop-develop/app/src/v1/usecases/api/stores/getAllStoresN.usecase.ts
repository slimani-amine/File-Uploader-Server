import {
  IStoreRepository,
  storeRepo,
} from "../../../data/repositories/store.repository";
import { ILike } from "typeorm";

export type GetAllStoresUseCaseType = (
  queryParams: { [key: string]: any },
  pagination: { page: number; perPage: number }
) => Promise<any>;

export const getAllStoresUseCaseBase =
  (dependencies: { storeRepo: IStoreRepository }): GetAllStoresUseCaseType =>
  async (queryParams: { [key: string]: any }, pagination) => {
    const skip = (pagination?.page - 1) * pagination?.perPage;

    const whereCondition: any = {};
    if (queryParams.name) {
      whereCondition.name = ILike(`%${queryParams.name}%`);
    }
    if (queryParams.isPublished) {
      whereCondition.isPublished = true;
    }

    const storesFound = pagination
      ? await dependencies.storeRepo.findAll({
          relations: {
            user: true,
          },
          where: whereCondition,
          select: {
            user: {
              id: true,
              email: true,
            },
          },
          skip,
          take: pagination?.perPage,
          order: {
            id: "DESC",
          },
        })
      : await dependencies.storeRepo.findAll({
          relations: {
            user: true,
          },
          where: whereCondition,
          select: {
            user: {
              id: true,
              email: true,
            },
          },
          order: {
            id: "DESC",
          },
        });

    const totalRecords = await dependencies.storeRepo.count(whereCondition);
    return { storesFound, totalRecords };
  };

export const getAllStoresUseCase = getAllStoresUseCaseBase({
  storeRepo: storeRepo,
});
