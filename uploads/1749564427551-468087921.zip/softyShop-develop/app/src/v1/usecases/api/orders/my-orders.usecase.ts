import { IOrder } from "../../../domain/order/order";
import {
  IOrderRepository,
  orderRepo,
} from "../../../data/repositories/orders.repository";
import { exceptionService } from "../../../core/errors/exceptions";

export type myOrdersUseCaseType = (
  cartId: string,
  pagination: { page: number; perPage: number }
) => Promise<{ orders: IOrder[]; totalRecords: number }>;

export const myOrdersUseCaseBase =
  (
    dependencies: {
      orderRepo: IOrderRepository;
    } = {
      orderRepo: orderRepo,
    }
  ): myOrdersUseCaseType =>
  async (userId, pagination) => {
    const skip = (pagination.page - 1) * pagination.perPage;
    try {
      const orders = await dependencies.orderRepo.findAll({
        relations: {
          cart: {
            cartProducts: {
              product: {
                store: true,
              },
            },
          },
        },
        where: {
          user: {
            id: userId,
          },
        },
        select: {
          id: true,
          status: true,
          isPaied: true,
          createdAt: true,
          cart: {
            id: true,
            totalAmount: true,
            totalQuantity: true,
            cartProducts: {
              product: {
                id: true,
                name: true,
                price: true,
                store: {
                  id: true,
                },
              },
            },
          },
        },
        skip,
        take: pagination.perPage,
      });

      if (!orders || orders.length === 0) {
        exceptionService.notFoundException({
          message: "Order not found",
        });
      }
      const totalRecords = await dependencies.orderRepo.count({
        user: {
          id: userId,
        },
      });

      return { orders, totalRecords };
    } catch (error) {
      throw error;
    }
  };

export const myOrdersUseCase: myOrdersUseCaseType = myOrdersUseCaseBase({
  orderRepo,
});
