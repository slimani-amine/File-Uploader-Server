import { exceptionService } from "../../../core/errors/exceptions";
import {
  ICategoryRepository,
  categoryRepo,
} from "../../../data/repositories/category.repository";

export type DeleteManyCategoriesUseCaseType = (ids: number[]) => Promise<number>;

export const deleteManyCategoriesUseCaseBase =
  (dependencies: { categoryRepo: ICategoryRepository }) => async (ids: number[]) => {
    const categorysFound = await dependencies.categoryRepo.deleteMany(ids);

    if (categorysFound === 0) {
      exceptionService.notFoundException({
        message: "Categories not found",
      });
    }

    return categorysFound;
  };

export const deleteManyCategoriesUseCase = deleteManyCategoriesUseCaseBase({
  categoryRepo: categoryRepo,
});
