import { productRepo } from "../../../data/repositories/product.repository";
import {
  IReviewRepository,
  reviewRepo,
} from "../../../data/repositories/review.repository";
import { IReview } from "../../../domain/reviews/reviews";

export type GetAllProductReviewsUseCaseType = (
  productId: string
) => Promise<IReview[]>;

export const getAllProductReviewsUseCaseBase =
  (dependencies: { reviewRepo: IReviewRepository }) =>
  async (productId: string): Promise<IReview[]> => {
    const product = (await productRepo.findOne({
      where: { id: productId },
    })) as any;

    const reviews = await dependencies.reviewRepo.findAll({
      where: { product:product },
    });

    return reviews;
  };

export const getAllProductReviewsUseCase: GetAllProductReviewsUseCaseType =
  getAllProductReviewsUseCaseBase({
    reviewRepo: reviewRepo,
  });
