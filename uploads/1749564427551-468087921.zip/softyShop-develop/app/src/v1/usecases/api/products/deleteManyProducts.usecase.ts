import { exceptionService } from "../../../core/errors/exceptions";
import {
  IProductRepository,
  productRepo,
} from "../../../data/repositories/product.repository";

export type DeleteManyProductsUseCaseType = (ids: number[]) => Promise<number>;

export const deleteManyProductsUseCaseBase =
  (dependencies: { productRepo: IProductRepository }) =>
  async (ids: number[]) => {
    const productsFound = await dependencies.productRepo.deleteMany(ids);

    if (productsFound === 0) {
      exceptionService.notFoundException({
        message: "Products not found",
      });
    }

    return productsFound;
  };

export const deleteManyProductsUseCase = deleteManyProductsUseCaseBase({
  productRepo: productRepo,
});
