import { exceptionService } from "../../../core/errors/exceptions";
import {
  IUsersRepository,
  usersRepo,
} from "../../../data/repositories/users.repository";

export type DeleteManyUsersUseCaseType = (ids: string[]) => Promise<number>;

export const deleteManyUsersUseCaseBase =
  (dependencies: { usersRepo: IUsersRepository }) => async (ids: string[]) => {
    const usersFound = await dependencies.usersRepo.deleteMany(ids);

    if (usersFound === 0) {
      exceptionService.notFoundException({
        message: "Users not found",
      });
    }

    return usersFound;
  };

export const deleteManyUsersUseCase = deleteManyUsersUseCaseBase({
  usersRepo: usersRepo,
});
