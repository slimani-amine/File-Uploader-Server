import { exceptionService } from "../../../core/errors/exceptions";
import {
  IProductCreatorRepository,
  productCreatorRepo,
} from "../../../data/repositories/productCreator.repository";

export type DeleteManyProductCreatorsUseCaseType = (
  ids: number[]
) => Promise<number>;

export const deleteManyProductCreatorsUseCaseBase =
  (dependencies: { productCreatorRepo: IProductCreatorRepository }) =>
  async (ids: number[]) => {
    const productCreatorsFound =
      await dependencies.productCreatorRepo.deleteMany(ids);

    if (productCreatorsFound === 0) {
      exceptionService.notFoundException({
        message: "ProductCreators not found",
      });
    }

    return productCreatorsFound;
  };

export const deleteManyProductCreatorsUseCase =
  deleteManyProductCreatorsUseCaseBase({
    productCreatorRepo: productCreatorRepo,
  });
