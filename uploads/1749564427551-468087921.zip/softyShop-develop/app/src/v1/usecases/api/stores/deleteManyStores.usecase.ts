import { productRepo } from "../../../data/repositories/product.repository";
import { exceptionService } from "../../../core/errors/exceptions";
import {
  IStoreRepository,
  storeRepo,
} from "../../../data/repositories/store.repository";

export type DeleteManyStoresUseCaseType = (ids: number[]) => Promise<number>;

export const deleteManyStoresUseCaseBase =
  (dependencies: {
    storeRepo: IStoreRepository;
  }): DeleteManyStoresUseCaseType =>
  async (ids: number[]) => {
    try {
      for (const id of ids) {
        const products = await productRepo.findAll({
          where: {
            store: {
              id: String(id), 
            },
          },
        });
        for (const product of products) {
          const deletedProduct = await productRepo.deleteProduct(product);
        }
      }

      const storesFound = await dependencies.storeRepo.deleteMany(ids);

      if (storesFound === 0) {
        throw exceptionService.notFoundException({
          message: "Stores not found",
        });
      }

      return storesFound;
    } catch (error) {
      throw error;
    }
  };

export const deleteManyStoresUseCase: DeleteManyStoresUseCaseType =
  deleteManyStoresUseCaseBase({
    storeRepo,
  });
