import { IOrder } from "../../../domain/order/order";
import {
  IOrderRepository,
  orderRepo,
} from "../../../data/repositories/orders.repository";

export type updateOrderStatusUseCaseType = (
  order: IOrder,
  payload: Partial<IOrder>
) => Promise<IOrder>;

export const updateOrderStatusUseCaseBase =
  (
    dependencies: {
      orderRepo: IOrderRepository;
    } = {
      orderRepo: orderRepo,
    }
  ): updateOrderStatusUseCaseType =>
  async (order: IOrder, payload: Partial<IOrder>) => {
    const updatedOrder = await dependencies.orderRepo.updateOrder(
      order,
      payload as any
    );

    return updatedOrder;
  };

export const updateOrderStatusUseCase: updateOrderStatusUseCaseType =
  updateOrderStatusUseCaseBase({
    orderRepo,
  });
