import {
  DataSource,
  DeepPartial,
  FindManyOptions,
  FindOneOptions,
  QueryRunner,
} from "typeorm";
import { ICreateOrderInput, IOrder, Order } from "../../domain/order/order";
import dataSource from "../connection";
import { OrderEntity } from "../orm_models/orders.entity";
import { calculateEstimatedDeliveryDate } from "../../utils/helpers/calculateEstimatedDay";

export const orderRepoBase = (dbConnection: DataSource | QueryRunner) => ({
  manager: dbConnection.manager,
  async findOne(findData: FindOneOptions<OrderEntity>): Promise<any> {
    const order = await this.manager.findOne(OrderEntity, findData);
    return order;
  },

  async findAll(findData: FindManyOptions<OrderEntity>): Promise<any[]> {
    const orders = await this.manager.find(OrderEntity, findData);
    return orders;
  },

  async createOrder(payload: ICreateOrderInput): Promise<any> {
    const order = this.manager.create(OrderEntity, {
      phoneNumber: payload.phoneNumber,
      totalQuantity: payload.totalQuantity,
      totalAmount: payload.totalAmount,
      estimatedDeliveryDate: calculateEstimatedDeliveryDate(),
      cart: { id: payload.cartId },
      user: {
        id: payload.userId,
      },
      address: {
        id: payload.address_id,
      },
      paymentMethod: {
        id: payload.paymentMethod_id,
      },
      isPaied: false,
    } as DeepPartial<OrderEntity>);

    const result = await this.manager.save(OrderEntity, order);
    return result;
  },

  async updateOrder(
    order: IOrder,
    payload: Partial<OrderEntity>
  ): Promise<IOrder> {
    payload.estimatedDeliveryDate = calculateEstimatedDeliveryDate();
    await this.manager.update(
      OrderEntity,
      {
        id: order.id,
      },
      payload
    );
    const updatedOrder = await this.manager.findOne(OrderEntity, {
      where: {
        id: order.id,
      },
    });
    return this.toDomainOrder(updatedOrder);
  },
  async deleteMany(payload: Array<number>): Promise<number> {
    const result = await this.manager.softDelete(OrderEntity, payload);
    return result.affected;
  },
  async count(whereCondition): Promise<number> {
    return await this.manager.count(OrderEntity, { where: whereCondition });
  },

  toDomainOrders(orders: OrderEntity[]): IOrder[] {
    const domainOrders = orders.map((prismaOrder) =>
      this.toDomainOrder(prismaOrder)
    );
    return domainOrders;
  },

  toDomainOrder(prismaOrder: OrderEntity): IOrder {
    if (!prismaOrder) {
      return null;
    }
    const order = new Order({
      id: prismaOrder.id,
      phoneNumber: prismaOrder.phoneNumber,
      estimatedDeliveryDate: prismaOrder.estimatedDeliveryDate,
      status: prismaOrder.status,
      totalAmount: prismaOrder.totalAmount,
      totalQuantity: prismaOrder.totalQuantity,
    });
    return order;
  },
});

export const orderRepo = orderRepoBase(dataSource);

export interface IOrderRepository {
  findOne(findData: FindOneOptions<OrderEntity>): Promise<IOrder>;
  findAll(findData: FindManyOptions<OrderEntity>): Promise<any[]>;

  createOrder(payload: ICreateOrderInput): Promise<IOrder>;
  updateOrder(order: IOrder, payload: Partial<OrderEntity>): Promise<IOrder>;
  deleteMany(payload: Array<number>): Promise<number>;
  count(whereCondition): Promise<number>;
}
