import {
  DataSource,
  DeepPartial,
  FindManyOptions,
  FindOneOptions,
  QueryRunner,
} from "typeorm";
import { NotificationsEntity } from "../orm_models/notifications.entity";
import {
  ICreateNotificationInput,
  INotification,
  Notification,
} from "../../domain/notifications/notifications";
import dataSource from "../connection";
import {
  ApiFeatures,
  QueryResult,
} from "../../utils/querying/apiFeatures.util";

export const notificationRepoBase = (
  dbConnection: DataSource | QueryRunner
) => ({
  manager: dbConnection.manager,

  async findOne(
    findData: FindOneOptions<NotificationsEntity>
  ): Promise<INotification> {
    const notification = await this.manager.findOne(
      NotificationsEntity,
      findData
    );
    return this.toDomainNotification(notification);
  },

  async findAll(
    findData: FindManyOptions<NotificationsEntity>
  ): Promise<any[]> {
    const notifications = await this.manager.find(
      NotificationsEntity,
      findData
    );
    return notifications;
  },

  async createNotification(payload: ICreateNotificationInput): Promise<any> {
    const notification = this.manager.create(NotificationsEntity, {
      message: payload.message,
      user: {
        id: payload.user_id,
      },
      order: {
        id: payload.order_id,
      },
      store: {
        id: payload.store_id,
      },
    } as DeepPartial<NotificationsEntity>);

    const result = await this.manager.save(NotificationsEntity, notification);
    return result;
  },

  async deleteNotification(notification: INotification): Promise<number> {
    const result = await this.manager.softDelete(NotificationsEntity, {
      id: notification.getIdAsNumber(),
    });
    return result !== null ? 1 : 0;
  },

  async deleteMany(payload: Array<number>): Promise<number> {
    const result = await this.manager.softDelete(NotificationsEntity, payload);
    return result.affected;
  },

  async findByQuery(queryParams: {
    [key: string]: string;
  }): Promise<QueryResult<INotification>> {
    const result = await ApiFeatures.generateSqlQuery(
      dataSource,
      "Notifications",
      queryParams,
      {}
    );
    return {
      docs: this.toDomainNotifications(result.docs),
      meta: result.meta,
    };
  },

  toDomainNotifications(notifications: NotificationsEntity[]): INotification[] {
    const domainNotifications = notifications.map((notification) =>
      this.toDomainNotification(notification)
    );
    return domainNotifications;
  },

  toDomainNotification(notification: NotificationsEntity): INotification {
    if (!notification) {
      return null;
    }
    const domainNotification = new Notification({
      id: notification.id,
      message: notification.message,
    });
    return domainNotification;
  },
});

export const notificationRepo = notificationRepoBase(dataSource);

export interface INotificationRepository {
  findOne(
    findData: FindOneOptions<NotificationsEntity>
  ): Promise<INotification>;
  findAll(findData: FindManyOptions<NotificationsEntity>): Promise<any[]>;
  findByQuery(queryParams: {
    [key: string]: string;
  }): Promise<QueryResult<INotification>>;
  createNotification(payload: ICreateNotificationInput): Promise<any>;
  deleteNotification(notification: INotification): Promise<number>;
  deleteMany(payload: Array<number>): Promise<number>;
}
