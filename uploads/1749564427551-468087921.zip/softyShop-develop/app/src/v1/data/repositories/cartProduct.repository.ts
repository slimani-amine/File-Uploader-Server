import {
  DataSource,
  QueryRunner,
  FindOneOptions,
  FindManyOptions,
} from "typeorm";
import { CartProductEntity } from "../orm_models/cartProduct.entity";
import { ProductEntity } from "../orm_models/product.entity";
import { CartEntity } from "../orm_models/cart.entity";
import { exceptionService } from "../../core/errors/exceptions";
import dataSource from "../connection";
import { cartRepo } from "./cart.repsitory";

export const cartProductRepoBase = (
  dbConnection: DataSource | QueryRunner
) => ({
  manager: dbConnection.manager,

  async findOne(
    findData: FindOneOptions<CartProductEntity>
  ): Promise<CartProductEntity> {
    const cartProduct = await this.manager.findOne(CartProductEntity, findData);
    return cartProduct;
  },

  async findAll(
    findData: FindManyOptions<CartProductEntity>
  ): Promise<CartProductEntity[]> {
    const cartProducts = await this.manager.find(CartProductEntity, findData);
    return cartProducts;
  },

  async createCartProduct(payload: {
    quantity: number;
    productId: string;
    cartId: string;
  }): Promise<CartProductEntity> {
    try {
      // Find the product
      const product = await this.manager.findOne(ProductEntity, {
        where: { id: payload.productId },
      });

      if (!product) {
        throw exceptionService.notFoundException({
          message: "Product not found",
        });
      }

      // Find the cart
      const cart = await this.manager.findOne(CartEntity, {
        where: { id: payload.cartId },
      });

      if (!cart) {
        throw exceptionService.notFoundException({
          message: "Cart not found",
        });
      }

      // Update cart quantities and total amount
      const updatedTotalQuantity = cart.totalQuantity + payload.quantity;
      const updatedTotalAmount =
        cart.totalAmount + payload.quantity * product.price;

      // Update the cart's total quantity and total amount
      const updateCart = await cartRepo.updateCart(cart, {
        totalQuantity: updatedTotalQuantity,
        totalAmount: updatedTotalAmount,
      });

      // Create a new CartProductEntity
      const cartProduct = this.manager.create(CartProductEntity, {
        quantity: payload.quantity,
        product: product,
        cart: cart,
      });

      // Save the new CartProductEntity to the database
      const savedCartProduct = await this.manager.save(
        CartProductEntity,
        cartProduct
      );

      return savedCartProduct;
    } catch (error) {
      throw error; // Re-throw the error to be handled by the caller
    }
  },
  async deleteCartProduct(cartProduct: CartProductEntity): Promise<number> {
    const result = await this.manager.softDelete(CartProductEntity, {
      product: { id: cartProduct.product.id },
    });
    return result !== null ? 1 : 0;
  },
  async deleteAllCartProducts(): Promise<number> {
    const result = await this.manager.softDelete(CartProductEntity, {});
    return result !== null ? 1 : 0;
  },
  async updateCartProduct(
    cartProduct: CartProductEntity,
    payload: Partial<CartProductEntity>
  ): Promise<any> {
    await this.manager.update(
      CartProductEntity,
      {
        id: cartProduct.id,
      },
      payload
    );
    const updatedProductCart = await this.manager.findOne(CartProductEntity, {
      where: {
        id: cartProduct.id,
      },
    });
    return updatedProductCart;
  },
});

export const cartProductRepo = cartProductRepoBase(dataSource);

export interface ICartProductRepository {
  findOne(
    findData: FindOneOptions<CartProductEntity>
  ): Promise<CartProductEntity>;
  findAll(
    findData: FindManyOptions<CartProductEntity>
  ): Promise<CartProductEntity[]>;
  createCartProduct(payload: {
    quantity: number;
    productId: string;
    cartId: string;
  }): Promise<CartProductEntity>;
  deleteCartProduct(cartProduct: CartProductEntity): Promise<number>;
  deleteAllCartProducts(): Promise<number>;
  updateCartProduct(
    cartProduct: CartProductEntity,
    payload: Partial<CartProductEntity>
  ): Promise<any>;
}
