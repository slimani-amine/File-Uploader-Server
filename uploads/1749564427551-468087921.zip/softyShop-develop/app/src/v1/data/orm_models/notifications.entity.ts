import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import {
  QueryDeepPartialEntity,
  WhereEntityOptions,
  findManyType,
} from "../../../types/repos";
import { UserEntity } from "./user.entity";
import { OrderEntity } from "./orders.entity";
import { StoreEntity } from "./store.entity";

@Entity({
  name: "Notifications",
})
export class NotificationsEntity {
  @PrimaryGeneratedColumn()
  id: string;

  @Column({
    type: "varchar",
  })
  message: string;

  @ManyToOne(() => UserEntity, (user) => user.addresses)
  @JoinColumn({ name: "user_id" })
  user: UserEntity;

  @ManyToOne(() => OrderEntity, (order) => order.notifications)
  @JoinColumn({ name: "order_id" })
  order: OrderEntity;

  @ManyToOne(() => StoreEntity, (store) => store.notifications)
  @JoinColumn({ name: "store_id" })
  store: StoreEntity;

  @DeleteDateColumn({ name: "deletedAt" })
  deletedAt: Date;

  @CreateDateColumn({ name: "createdAt" })
  createdAt: Date;

  @UpdateDateColumn({ name: "updatedAt" })
  updatedAt: Date;
}

export type AddressesWherePayload = WhereEntityOptions<NotificationsEntity>;
export type AddressesUpdateDataPayload =
  QueryDeepPartialEntity<NotificationsEntity>;
export type AddressesFindPayload = findManyType<NotificationsEntity>;
