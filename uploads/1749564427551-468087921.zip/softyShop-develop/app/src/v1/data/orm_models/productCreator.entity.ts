import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import {
  QueryDeepPartialEntity,
  WhereEntityOptions,
  findManyType,
} from "../../../types/repos";
import { ProductEntity } from "./product.entity";

@Entity({
  name: "ProductCreators",
})
export class ProductCreatorEntity {
  @PrimaryGeneratedColumn()
  id: string;

  @Column({
    type: "varchar",
  })
  name: string;

  @OneToMany(() => ProductEntity, (product) => product.brand)
  products: ProductEntity[];


  @DeleteDateColumn({ name: "deletedAt" })
  deletedAt: Date;

  @CreateDateColumn({ name: "createdAt" })
  createdAt: Date;

  @UpdateDateColumn({ name: "updatedAt" })
  updatedAt: Date;
}

export type ProductCreatorWherePayload =
  WhereEntityOptions<ProductCreatorEntity>;
export type ProductCreatorUpdateDataPayload =
  QueryDeepPartialEntity<ProductCreatorEntity>;
export type ProductCreatorFindPayload = findManyType<ProductCreatorEntity>;
