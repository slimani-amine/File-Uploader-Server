import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import {
  QueryDeepPartialEntity,
  WhereEntityOptions,
  findManyType,
} from "../../../types/repos";
import { StoreEntity } from "./store.entity";
import { ProductCreatorEntity } from "./productCreator.entity";
import { CategoryEntity } from "./category.entity";
import { BrandEntity } from "./productBrand.entity";
import ReviewsEntity from "./reviews.entity";
import { WishlistEntity } from "./wishlist.entity";
import { CartProductEntity } from "./cartProduct.entity";

@Entity({
  name: "Products",
})
export class ProductEntity {
  @PrimaryGeneratedColumn()
  id: string;

  @Column({
    type: "varchar",
  })
  name: string;

  @Column({
    type: "varchar",
    nullable: true,
  })
  description: string;

  @Column({
    type: "longtext",
    nullable: true,
  })
  similar: string;

  @Column({
    type: "longtext",
  })
  images: string;

  @Column({
    type: "float",
  })
  initialPrice: number;

  @Column({
    type: "float",
  })
  price: number;

  @Column({
    type: "int",
  })
  stockNumber: number;

  @Column({
    type: "int",
    default: 0,
  })
  discount: number;

  @Column({
    type: "date",
  })
  publishedAt: Date;

  @Column({
    type: "boolean",
    default: true,
  })
  availability: boolean;

  @Column({
    type: "boolean",
    default: false,
  })
  isPublished: boolean;

  @OneToMany(() => ReviewsEntity, (review) => review.product, {
    cascade: true,
  })
  reviews: ReviewsEntity[];

  @OneToMany(() => WishlistEntity, (wishlist) => wishlist.product, {
    cascade: true,
  })
  wishlist: WishlistEntity[];

  @OneToMany(() => CartProductEntity, (cartProduct) => cartProduct.product)
  cartProducts: CartProductEntity[];

  @ManyToOne(() => BrandEntity, (brand) => brand.products, {
    onDelete: "CASCADE",
  })
  @JoinColumn({ name: "brand_id" })
  brand: BrandEntity;

  @ManyToOne(() => ProductCreatorEntity, (creator) => creator.products, {
    onDelete: "CASCADE",
  })
  @JoinColumn({ name: "creator_id" })
  creator: ProductCreatorEntity;

  @ManyToOne(() => StoreEntity, (store) => store.products, {
    onDelete: "CASCADE",
  })
  @JoinColumn({ name: "store_id" })
  store: StoreEntity;

  @ManyToOne(() => CategoryEntity, (category) => category.product, {
    onDelete: "CASCADE",
  })
  @JoinColumn({ name: "category_id" })
  category: CategoryEntity;

  @DeleteDateColumn({ name: "deletedAt" })
  deletedAt: Date;

  @CreateDateColumn({ name: "createdAt" })
  createdAt: Date;

  @UpdateDateColumn({ name: "updatedAt" })
  updatedAt: Date;
}

export type ProductWherePayload = WhereEntityOptions<ProductEntity>;
export type ProductUpdateDataPayload = QueryDeepPartialEntity<ProductEntity>;
export type ProductFindPayload = findManyType<ProductEntity>;
