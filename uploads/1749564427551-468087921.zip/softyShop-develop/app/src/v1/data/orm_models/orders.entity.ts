import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import {
  QueryDeepPartialEntity,
  WhereEntityOptions,
  findManyType,
} from "../../../types/repos";
import { CartEntity } from "./cart.entity";
import { PaymentMethodEntity } from "./paymentMethod.entity";
import { AddressesEntity } from "./addresses.entity";
import { UserEntity } from "./user.entity";
import { NotificationsEntity } from "./notifications.entity";

@Entity({
  name: "Orders",
})
export class OrderEntity {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({
    type: "date",
  })
  estimatedDeliveryDate: Date;

  @Column({
    type: "int",
    default: 0,
  })
  totalQuantity: number;

  @Column({
    type: "int",
    default: 0,
  })
  totalAmount: number;

  @Column({
    type: "boolean",
    default: false,
  })
  isPaied: Date;

  @Column({
    type: "varchar",
    default: "",
  })
  phoneNumber: string;

  @Column({
    type: "enum",
    enum: ["processing", "on_delivery", "delivered", "cancelled"],
    default: "processing",
  })
  status: string;

  @ManyToOne(
    () => PaymentMethodEntity,
    (paymentMethod) => paymentMethod.order,
    {
      onDelete: "CASCADE",
    }
  )
  @JoinColumn({ name: "paymentMethod_id" })
  paymentMethod: PaymentMethodEntity;

  @ManyToOne(() => UserEntity, (user) => user.wishlist, {
    onDelete: "CASCADE",
  })
  @JoinColumn({ name: "user_id" })
  user: UserEntity;

  @ManyToOne(() => AddressesEntity, (addresses) => addresses.order, {
    onDelete: "CASCADE",
  })
  @JoinColumn({ name: "address_id" })
  address: AddressesEntity;

  @ManyToOne(() => CartEntity, (cart) => cart.order, {
    onDelete: "CASCADE",
  })
  @JoinColumn({ name: "cart_id" })
  cart: CartEntity;

  @OneToMany(() => NotificationsEntity, (notif) => notif.user)
  notifications: NotificationsEntity[];

  @DeleteDateColumn({ name: "deletedAt" })
  deletedAt: Date;

  @CreateDateColumn({ name: "createdAt" })
  createdAt: Date;

  @UpdateDateColumn({ name: "updatedAt" })
  updatedAt: Date;
}

export type OrderWherePayload = WhereEntityOptions<OrderEntity>;
export type OrderUpdateDataPayload = QueryDeepPartialEntity<OrderEntity>;
export type OrderFindPayload = findManyType<OrderEntity>;
