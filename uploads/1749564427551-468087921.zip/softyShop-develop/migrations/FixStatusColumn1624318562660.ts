import {MigrationInterface, QueryRunner} from "typeorm";

export class FixStatusColumn1624318562660 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
        // Drop the status column
        await queryRunner.query(`ALTER TABLE \`Orders\` DROP COLUMN \`status\``);

        // Add the status column again with the desired definition
        await queryRunner.query(`ALTER TABLE \`Orders\` ADD COLUMN \`status\` enum ('processing', 'on_delivery', 'delivered', 'cancelled') NOT NULL DEFAULT 'processing'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        // Rolling back the drop and add operations
        await queryRunner.query(`ALTER TABLE \`Orders\` DROP COLUMN \`status\``);
        await queryRunner.query(`ALTER TABLE \`Orders\` ADD COLUMN \`status\` enum ('processing', 'on_delivery', 'delivered', 'cancelled') NOT NULL DEFAULT 'processing'`);
    }

}
