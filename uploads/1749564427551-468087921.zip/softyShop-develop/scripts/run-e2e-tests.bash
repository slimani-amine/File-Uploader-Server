npm run reset-test-db
npm run jest-e2e-tests