# Starter Express
Run npm i
Then :
Use 'npm run docker-dev-start -b' to start the server
if it doesn't work
use 'npm run docker-dev-start -- -b'

=> This Repo Uses Husky For Commit Linting 
Commits Need To Have This Format

TYPE(SCOPE): SUBJECT

TYPE CAN ONLY BE: CHORE, FEATURE, FIX, HOTFIX
SUBJECT SHOULD BE LOWERCASE
SCOPE SHOULD BE UPPERCASE 