docker stop starterdevapi
docker stop starterdevdb
docker stop startertestdb
docker stop starterdevadminer