import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { UploadDropzone } from '@/components/upload-dropzone';
import { FileQueue } from '@/components/file-queue';
import { useUploadQueue } from '@/hooks/use-upload-queue';

export default function FileUploader() {
  const {
    queue,
    stats,
    isPaused,
    addFiles,
    removeFile,
    retryFile,
    clearCompleted,
    retryAllFailed,
    pauseQueue,
  } = useUploadQueue();

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto p-6 space-y-6">
        {/* Header */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">File Upload Manager</CardTitle>
            <p className="text-muted-foreground">
              Upload multiple files with intelligent queue management
            </p>
          </CardHeader>
        </Card>

        {/* Upload Zone */}
        <Card>
          <CardContent className="pt-6">
            <UploadDropzone
              onFilesSelected={addFiles}
              disabled={isPaused}
            />
          </CardContent>
        </Card>

        {/* File Queue */}
        <FileQueue
          queue={queue}
          stats={stats}
          isPaused={isPaused}
          onRetryFile={retryFile}
          onRemoveFile={removeFile}
          onClearCompleted={clearCompleted}
          onRetryAllFailed={retryAllFailed}
          onPauseQueue={pauseQueue}
        />
      </div>
    </div>
  );
}
