import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Trash2, RotateCcw, Download } from 'lucide-react';
import type { QueuedFile, UploadStats } from '@shared/schema';
import { formatFileSize, getFileIcon } from '@/lib/upload-utils';

interface FileQueueProps {
  queue: QueuedFile[];
  stats: UploadStats;
  isPaused: boolean;
  onRetryFile: (id: string) => void;
  onRemoveFile: (id: string) => void;
  onClearCompleted: () => void;
  onRetryAllFailed: () => void;
  onPauseQueue: () => void;
}

function getStatusBadge(status: QueuedFile['status']) {
  switch (status) {
    case 'uploading':
      return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Uploading</Badge>;
    case 'completed':
      return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Completed</Badge>;
    case 'failed':
      return <Badge variant="destructive">Failed</Badge>;
    case 'retrying':
      return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Retrying</Badge>;
    case 'queued':
    default:
      return <Badge variant="secondary">Queued</Badge>;
  }
}

function FileItem({ file, onRetry, onRemove }: { 
  file: QueuedFile; 
  onRetry: (id: string) => void;
  onRemove: (id: string) => void;
}) {
  return (
    <div className="flex items-center space-x-4 p-4 border rounded-lg bg-card hover:shadow-sm transition-shadow">
      <div className="text-2xl flex-shrink-0">
        {getFileIcon(file.file.type)}
      </div>
      
      <div className="flex-1 min-w-0 space-y-1">
        <p className="font-medium truncate">{file.file.name}</p>
        <p className="text-sm text-muted-foreground">{formatFileSize(file.file.size)}</p>
        
        {(file.status === 'uploading' || file.status === 'failed') && (
          <div className="space-y-1">
            <Progress 
              value={file.progress} 
              className={`h-1 ${file.status === 'failed' ? 'bg-red-100' : ''}`}
            />
            {file.status === 'failed' && file.error && (
              <p className="text-xs text-destructive">{file.error}</p>
            )}
          </div>
        )}
        
        {file.status === 'failed' && (
          <Button
            variant="link"
            size="sm"
            onClick={() => onRetry(file.id)}
            className="h-auto p-0 text-xs"
          >
            <RotateCcw className="w-3 h-3 mr-1" />
            Retry Upload
          </Button>
        )}
      </div>
      
      <div className="flex items-center space-x-2">
        {getStatusBadge(file.status)}
        
        {file.retryCount > 0 && (
          <Badge variant="outline" className="text-xs">
            Retry {file.retryCount}
          </Badge>
        )}
        
        {file.status === 'completed' && file.uploadedFileId && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => window.open(`/api/files/${file.uploadedFileId}/download`, '_blank')}
          >
            <Download className="w-4 h-4" />
          </Button>
        )}
        
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onRemove(file.id)}
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}

export function FileQueue({
  queue,
  stats,
  isPaused,
  onRetryFile,
  onRemoveFile,
  onClearCompleted,
  onRetryAllFailed,
  onPauseQueue,
}: FileQueueProps) {
  return (
    <div className="space-y-6">
      {/* Queue Status Alert */}
      {stats.uploading > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <p className="text-sm text-yellow-800">
            <strong>Queue Status:</strong> Currently uploading {stats.uploading} of 2 maximum concurrent files.
            {stats.queued > 0 && ` ${stats.queued} files waiting in queue.`}
          </p>
        </div>
      )}

      {/* Upload Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 p-4 bg-muted rounded-lg">
        <div className="text-center">
          <div className="text-2xl font-semibold">{stats.totalFiles}</div>
          <div className="text-xs text-muted-foreground uppercase tracking-wide">Total Files</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-semibold">{stats.uploading}</div>
          <div className="text-xs text-muted-foreground uppercase tracking-wide">Uploading</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-semibold">{stats.completed}</div>
          <div className="text-xs text-muted-foreground uppercase tracking-wide">Completed</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-semibold">{stats.failed}</div>
          <div className="text-xs text-muted-foreground uppercase tracking-wide">Failed</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-semibold">{stats.queued}</div>
          <div className="text-xs text-muted-foreground uppercase tracking-wide">In Queue</div>
        </div>
      </div>

      {/* File List */}
      <Card>
        <CardHeader>
          <CardTitle>Upload Queue</CardTitle>
          <p className="text-sm text-muted-foreground">
            Files are processed 2 at a time for optimal performance
          </p>
        </CardHeader>
        <CardContent className="space-y-3">
          {queue.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No files in queue. Drop files above to get started.
            </div>
          ) : (
            queue.map(file => (
              <FileItem
                key={file.id}
                file={file}
                onRetry={onRetryFile}
                onRemove={onRemoveFile}
              />
            ))
          )}
        </CardContent>
      </Card>

      {/* Action Buttons */}
      {queue.length > 0 && (
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-wrap gap-2">
              <Button
                variant={isPaused ? "default" : "secondary"}
                onClick={onPauseQueue}
              >
                {isPaused ? 'Resume Queue' : 'Pause Queue'}
              </Button>
              
              {stats.completed > 0 && (
                <Button
                  variant="outline"
                  onClick={onClearCompleted}
                >
                  Clear Completed
                </Button>
              )}
              
              {stats.failed > 0 && (
                <Button
                  variant="outline"
                  onClick={onRetryAllFailed}
                >
                  Retry All Failed
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
